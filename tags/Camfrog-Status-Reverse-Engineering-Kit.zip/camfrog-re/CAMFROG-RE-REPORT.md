# Camfrog Video Chat.exe — Reverse Engineering Report

## Scope
Static reverse engineering focused only on the custom-status feature and a stable local integration route for Camfrog Status Changer. Credential/session extraction, authentication bypass, and unrelated user-data recovery are out of scope.

## Sample identity
- File: `Camfrog Video Chat.exe`
- Format: PE32+ / x86-64 / Windows GUI
- Size: ~59 MiB
- SHA-256: `0b744602c004536dcf81e9965e8cb17358eb276b3876a1e70c50f72777c27e06`
- Link timestamp: 2026-08-28 10:17:29 UTC (PE header value; timestamps can be altered)
- Image base: `0x140000000`
- Entry RVA: `0x24354c4`
- Sections: `.text`, `.rdata`, `.data`, `.pdata`, `_RDATA`, `.rsrc`, `.reloc`
- Mitigations visible in PE header: ASLR (`DYNAMIC_BASE`), DEP/NX (`NX_COMPAT`), High Entropy VA.

## Method derived from wtsxDev/reverse-engineering
The referenced repository is a curated RE tool/resource list. For this target, its useful categories map to:
1. Binary format inspection: Detect It Easy / PeStudio / CFF Explorer.
2. Static disassembly: Ghidra / IDA / Binary Ninja / objdump.
3. Dynamic analysis: Process Monitor, API Monitor, TCPView/Wireshark.
4. Debugging: x64dbg / WinDbg.
5. Scripting: IDAPython/Ghidra scripting and PE helpers.

The current pass used PE-header inspection, import inspection, ASCII/UTF-16 string extraction, RTTI/protobuf anchors, and resource/control-name correlation. Dynamic execution was not performed in this Linux analysis environment.

## High-confidence static findings

### UI/resource anchors
Present in the binary:
- `custom_status_combo`
- `custom_status_combo_combo`
- `custom_status_text`
- `change_status_button`
- `status_menu`
- `status_button`
- `tooltip_custom_status`
- `menu_cl_copy_custom_status`
- `CComboBoxTS`
- `CEdit4ComboInnerTS`
- `CButtonStatusTS`

This strongly supports that the custom-status editor is a native/custom WTL/ATL control hierarchy rather than a normal HTML input.

### Internal message-layer RTTI anchors
Present in RTTI/type names:
- `Messages::ChangeStatus`
- `Messages::CSNet_Status`
- `Messages::CSNet_SetSelfStatus`
- `Messages::CSNet_ChangeStatusEx`
- `Messages::CSToNet_SetSelfStatus`
- `Messages::CSToNet_GetStatus`
- `Messages::PreviousAutoAwayStatus`

These names are substantially better tracing anchors than synthetic Win32 combo notifications.

### Protocol/schema anchors
Present in the binary:
- `proto.client.user.CSPacket020401.text_status`
- `proto.client.user.CSPacket020402.custom_status`
- `proto.client.user.ClientProfile.User.custom_status`
- `proto.client.user.ClientProfile.ChatRoom.custom_status`
- `proto.client.user.ClientProfile.Bot.custom_status`
- feature string includes `exStatusUpdate`

**Inference to verify dynamically:** `CSPacket020401.text_status` is a strong candidate for the outgoing self-status update payload, while `CSPacket020402.custom_status` appears consistent with a profile/status representation received or distributed elsewhere. Static strings alone do not prove direction or call order.

### Registry anchors
UTF-16 strings include:
- `Software\\Camfrog\\Client`
- `Software\\Camfrog\\Client\\CurrentVersion\\ProfileInfo\\`
- `\\CurrentVersion\\ProfileInfo\\Nickname List2`
- `\\Custom status list`
- `ProfileInfo`

This explains why old/custom status history can exist in local profile data. Registry state should not be treated as proof that a server-side status update has occurred.

### Framework/network surface
Imports include `libcef.dll`; the executable also imports standard Windows networking/runtime APIs. CEF presence does not imply the custom status control itself is browser-rendered; UI anchors and WTL/ATL RTTI indicate native custom controls are involved.

## Candidate custom-status pipeline
The following is a research hypothesis assembled from static anchors and must be confirmed by xrefs/dynamic tracing:

```text
custom_status_combo / CComboBoxTS
        │
        ├── change_status_button
        │
        ▼
Messages::ChangeStatus
        ▼
Messages::CSToNet_SetSelfStatus
        ▼
Messages::CSNet_SetSelfStatus / CSNet_ChangeStatusEx
        ▼
proto.client.user.CSPacket020401.text_status
        ▼
network transport / server
        ▼
remote profile update (candidate: CSPacket020402.custom_status)
```

Do not implement an in-process call based solely on this hypothesis. First confirm exact functions, object lifetime/thread, argument layout, and ownership in Ghidra/x64dbg.

## Why WM_SETTEXT/CBN_* was insufficient
`CComboBoxTS` is a custom class. Updating its edit buffer can change visible text while bypassing the application-level handler that constructs a `Messages::*Status*` object or a protobuf packet. Therefore a successful `WM_SETTEXT` is not equivalent to a published status update.

## Recommended dynamic trace — minimal and targeted

### Phase A — Ghidra xrefs
1. Import the exact SHA-256 sample.
2. Run full analysis with MSVC RTTI enabled.
3. Search defined strings for:
   - `custom_status_combo`
   - `change_status_button`
   - `proto.client.user.CSPacket020401.text_status`
   - `.?AUChangeStatus@Messages@@`
   - `.?AUCSToNet_SetSelfStatus@Messages@@`
   - `.?AUCSNet_SetSelfStatus@Messages@@`
4. Follow all DATA and instruction references.
5. Rename functions based on observed behavior, not guesses.
6. Trace from the UI resource lookup/binding function to the button/selection handler.
7. Trace constructors/dispatchers for the `Messages::*Status*` RTTI types.
8. Locate protobuf setters/serialization for `CSPacket020401::text_status`.

### Phase B — x64dbg differential trace
Use two controlled actions only:
- Baseline: open the status combo, cancel/no change.
- Test: set a unique marker such as `CF_RE_TEST_8F31` and commit through the official UI.

Break/log around functions identified by Ghidra. Compare which handler executes only on the committed change. Record:
- module-relative RVA (not absolute ASLR address)
- calling thread
- RCX/RDX/R8/R9 at entry
- object/type observations
- return path
- subsequent packet-builder/transport call

Avoid breakpoints on credential/login routines.

### Phase C — Process Monitor / registry differential
Filter Process Name = Camfrog executable. Capture only RegSetValue/File writes while performing one official status change. This determines whether `Custom status list` is merely history or participates in commit.

### Phase D — network differential
If permitted in your environment, capture only your own Camfrog traffic metadata while changing one unique marker. TLS may prevent payload inspection without invasive interception; endpoint/timing/size correlation is still useful. Do not disable certificate validation or extract session secrets.

## Integration choices after confirmation
Preferred order:
1. **Documented/official API**, if Camfrog exposes one for custom status.
2. **Native UI command routed through the real application handler**, using the exact command/control ID discovered dynamically.
3. **Local IPC/message dispatcher**, if a stable existing app IPC mechanism is confirmed.
4. UI automation only as fallback.

Avoid direct invocation of arbitrary internal function addresses in production unless version-gated and thoroughly validated; internal ABI changes between Camfrog releases can crash the client or corrupt state.

## Version gating requirements
Before enabling a reverse-engineered adapter:
- verify file SHA-256 or signed file version
- verify expected control classes/resources
- verify expected RVA/signature for traced handler
- fail closed on mismatch
- never scan or patch unrelated memory
- keep foreground/UI fallback separately opt-in

## Current conclusions
1. The status feature is not just a plain Win32 ComboBox.
2. The executable contains explicit application-level status message types.
3. A protobuf field named `CSPacket020401.text_status` is a high-value anchor for the outgoing status path.
4. `WM_SETTEXT` success cannot verify remote status publication.
5. The next productive step is xref + differential debugger tracing from `change_status_button` / `Messages::ChangeStatus` into `CSToNet_SetSelfStatus` and the `CSPacket020401.text_status` builder.
