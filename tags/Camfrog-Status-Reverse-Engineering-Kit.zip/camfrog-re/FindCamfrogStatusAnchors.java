// Ghidra script: FindCamfrogStatusAnchors.java
// @category Camfrog
// Read-only helper: finds known custom-status strings/RTTI anchors and prints xrefs.

import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.data.StringDataInstance;
import ghidra.program.model.listing.Data;
import ghidra.program.model.listing.Listing;
import ghidra.program.model.symbol.Reference;
import java.util.*;

public class FindCamfrogStatusAnchors extends GhidraScript {
    private static final String[] NEEDLES = {
        "custom_status_combo",
        "custom_status_combo_combo",
        "custom_status_text",
        "change_status_button",
        "status_menu",
        "status_button",
        "tooltip_custom_status",
        "\\Custom status list",
        "Software\\Camfrog\\Client\\CurrentVersion\\ProfileInfo\\",
        ".?AVCComboBoxTS@@",
        ".?AUChangeStatus@Messages@@",
        ".?AUCSNet_SetSelfStatus@Messages@@",
        ".?AUCSNet_ChangeStatusEx@Messages@@",
        ".?AUCSToNet_SetSelfStatus@Messages@@",
        ".?AUCSToNet_GetStatus@Messages@@",
        "proto.client.user.CSPacket020401.text_status",
        "proto.client.user.CSPacket020402.custom_status",
        "proto.client.user.ClientProfile.User.custom_status"
    };

    @Override
    public void run() throws Exception {
        Listing listing = currentProgram.getListing();
        Set<String> wanted = new HashSet<>(Arrays.asList(NEEDLES));
        int hits = 0;

        for (Data d : listing.getDefinedData(true)) {
            if (monitor.isCancelled()) break;
            if (!d.hasStringValue()) continue;
            String s;
            try {
                s = StringDataInstance.getStringDataInstance(d).getStringValue();
            } catch (Exception e) {
                continue;
            }
            if (s == null || !wanted.contains(s)) continue;

            hits++;
            Address a = d.getAddress();
            println("\n[ANCHOR] " + s + " @ " + a);
            Reference[] refs = getReferencesTo(a);
            if (refs.length == 0) {
                println("  (no direct xrefs; RTTI/resources may require following surrounding structures)");
            }
            for (Reference r : refs) {
                Address from = r.getFromAddress();
                println("  <- " + from + "  type=" + r.getReferenceType());
                if (getFunctionContaining(from) != null) {
                    println("     function=" + getFunctionContaining(from).getName() +
                            " @ " + getFunctionContaining(from).getEntryPoint());
                }
            }
        }
        println("\nDone. Exact anchor hits: " + hits);
    }
}
