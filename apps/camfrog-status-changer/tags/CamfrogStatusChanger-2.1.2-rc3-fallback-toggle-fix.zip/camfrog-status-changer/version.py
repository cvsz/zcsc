APP_NAME = "Camfrog Status Changer"
APP_ID = "CamfrogStatusChanger"
VERSION = "2.1.1-rc2"
