from __future__ import annotations

import random
import threading
import time
from collections.abc import Callable


class RotationWorker:
    def __init__(self, apply_status: Callable[[str], None]):
        self.apply_status = apply_status
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._idx = 0

    def start(self, presets: list[str], interval_seconds: int, mode: str) -> None:
        self.stop()
        self._stop.clear()

        def run() -> None:
            # Wait one full interval before the first automatic change.
            # This prevents an immediate status flip as soon as rotation starts.
            interval = max(1, interval_seconds)
            while not self._stop.wait(interval):
                if presets:
                    if mode == "random":
                        value = random.choice(presets)
                    else:
                        value = presets[self._idx % len(presets)]
                        self._idx += 1
                    self.apply_status(value)

        self._thread = threading.Thread(target=run, daemon=True, name="status-rotation")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)
        self._thread = None
