from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "CamfrogStatusChanger"


def startup_shortcut_path() -> Path:
    appdata = Path(os.environ["APPDATA"])
    return appdata / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / f"{APP_NAME}.cmd"


def launch_command() -> str:
    exe = Path(sys.executable).resolve()
    if getattr(sys, "frozen", False):
        return f'start "" "{exe}"'
    script = Path(__file__).resolve().parents[1] / "app.py"
    return f'start "" "{exe}" "{script}"'


def set_start_with_windows(enabled: bool) -> None:
    if os.name != "nt":
        return
    path = startup_shortcut_path()
    if enabled:
        path.write_text(f"@echo off\n{launch_command()}\n", encoding="utf-8")
    elif path.exists():
        path.unlink()
