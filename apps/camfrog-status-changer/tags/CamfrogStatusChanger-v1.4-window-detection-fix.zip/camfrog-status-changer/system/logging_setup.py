from __future__ import annotations

import logging
import os
from pathlib import Path


def configure_logging() -> None:
    appdata = os.getenv("APPDATA")
    base = Path(appdata) if appdata else (Path.home() / ".config")
    log_dir = base / "CamfrogStatusChanger" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_dir / "app.log", encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )
