from __future__ import annotations

import logging
import sys
import threading
import time
from pathlib import Path

from ui.dashboard import AppUI
from system.logging_setup import configure_logging
from system.config_store import ConfigStore


def main() -> int:
    configure_logging()
    log = logging.getLogger("camfrog_status")
    store = ConfigStore()
    try:
        store.ensure_defaults()
        app = AppUI(store=store)
        app.mainloop()
        return 0
    except Exception:
        log.exception("Fatal application error")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
