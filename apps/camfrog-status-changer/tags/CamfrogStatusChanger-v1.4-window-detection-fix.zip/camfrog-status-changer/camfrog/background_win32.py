from __future__ import annotations

import logging
import os
from dataclasses import dataclass

log = logging.getLogger(__name__)


@dataclass
class BackgroundResult:
    ok: bool
    message: str
    hwnd: int = 0


def _require_windows() -> None:
    if os.name != "nt":
        raise RuntimeError("Win32 background automation is available on Windows only")


def _make_lparam(x: int, y: int) -> int:
    return ((y & 0xFFFF) << 16) | (x & 0xFFFF)


def _send_timeout(hwnd: int, msg: int, wparam=0, lparam=0, timeout_ms: int = 800):
    import win32con
    import win32gui
    return win32gui.SendMessageTimeout(
        hwnd, msg, wparam, lparam,
        win32con.SMTO_ABORTIFHUNG | win32con.SMTO_BLOCK,
        timeout_ms,
    )


def _children(parent_hwnd: int) -> list[int]:
    import win32gui
    result: list[int] = []
    try:
        win32gui.EnumChildWindows(parent_hwnd, lambda h, _: result.append(h) or True, None)
    except Exception:
        pass
    return result


def enumerate_native_controls(parent_hwnd: int) -> list[dict]:
    """Dump native HWND metadata. Useful for Camfrog builds with custom UI wrappers."""
    _require_windows()
    import win32gui
    out: list[dict] = []
    for hwnd in [parent_hwnd] + _children(parent_hwnd):
        try:
            out.append({
                "hwnd": int(hwnd),
                "class_name": win32gui.GetClassName(hwnd) or "",
                "text": win32gui.GetWindowText(hwnd) or "",
                "visible": bool(win32gui.IsWindowVisible(hwnd)),
                "enabled": bool(win32gui.IsWindowEnabled(hwnd)),
                "rect": list(win32gui.GetWindowRect(hwnd)),
            })
        except Exception:
            continue
    return out


def _smallest_child_at_point(parent_hwnd: int, screen_x: int, screen_y: int) -> int:
    import win32gui
    candidates: list[tuple[int, int]] = []
    for hwnd in _children(parent_hwnd):
        try:
            if not win32gui.IsWindow(hwnd):
                continue
            left, top, right, bottom = win32gui.GetWindowRect(hwnd)
            if left <= screen_x < right and top <= screen_y < bottom:
                area = max(1, right - left) * max(1, bottom - top)
                candidates.append((area, hwnd))
        except Exception:
            pass
    if candidates:
        candidates.sort(key=lambda item: item[0])
        return candidates[0][1]
    return parent_hwnd


def _read_text(hwnd: int) -> str:
    import win32gui
    try:
        return win32gui.GetWindowText(hwnd) or ""
    except Exception:
        return ""


def _class_name(hwnd: int) -> str:
    import win32gui
    try:
        return win32gui.GetClassName(hwnd) or ""
    except Exception:
        return ""


def _find_edit_candidate(hwnd: int) -> int | None:
    pool = [hwnd] + _children(hwnd)
    for child in pool:
        cls = _class_name(child).lower()
        if "edit" in cls or "richedit" in cls:
            return child
    return None


def _find_camfrog_status_combo(parent_hwnd: int, current_text: str = "") -> int | None:
    """Prefer Camfrog's native status combo discovered from static analysis.

    Camfrog 2026 build contains internal resource id `custom_status_combo` and
    custom window class `CComboBoxTS`. There can be more than one combo, so
    score by current text and geometry near the top profile/status area.
    """
    import win32gui

    candidates: list[tuple[int, int]] = []
    try:
        pl, pt, pr, pb = win32gui.GetWindowRect(parent_hwnd)
        ph = max(1, pb - pt)
    except Exception:
        pl = pt = pr = pb = 0
        ph = 1

    for hwnd in _children(parent_hwnd):
        try:
            cls = _class_name(hwnd).lower()
            if cls != "ccomboboxts" and "combobox" not in cls:
                continue
            text = _read_text(hwnd)
            l, t, r, b = win32gui.GetWindowRect(hwnd)
            score = 0
            if cls == "ccomboboxts":
                score += 100
            if current_text and text.strip() == current_text.strip():
                score += 200
            # Status field observed in the upper profile section of the main window.
            rel_y = (t - pt) / ph if ph else 1.0
            if 0.08 <= rel_y <= 0.40:
                score += 50
            width = max(0, r - l)
            if width >= 120:
                score += 10
            candidates.append((score, hwnd))
        except Exception:
            continue

    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[0][1]


def _send_key(hwnd: int, vk: int, *, ctrl: bool = False) -> None:
    import win32con
    if ctrl:
        _send_timeout(hwnd, win32con.WM_KEYDOWN, win32con.VK_CONTROL, 0)
    _send_timeout(hwnd, win32con.WM_KEYDOWN, vk, 0)
    _send_timeout(hwnd, win32con.WM_KEYUP, vk, 0)
    if ctrl:
        _send_timeout(hwnd, win32con.WM_KEYUP, win32con.VK_CONTROL, 0)


def _set_native_combo_text(combo_hwnd: int, value: str) -> BackgroundResult:
    """Set Camfrog CComboBoxTS without foreground activation."""
    import win32con
    import win32gui

    # Prefer an embedded Edit HWND if the combo exposes one.
    edit = _find_edit_candidate(combo_hwnd)
    if edit:
        _send_timeout(edit, win32con.WM_SETTEXT, 0, value, timeout_ms=1200)
        _send_key(edit, win32con.VK_RETURN)
        return BackgroundResult(True, "Camfrog native status combo updated via child Edit", edit)

    # Custom CComboBoxTS often receives text itself. WM_SETTEXT is bounded and
    # does not activate the window. Enter asks the wrapper to commit the value.
    _send_timeout(combo_hwnd, win32con.WM_SETTEXT, 0, value, timeout_ms=1200)
    after = _read_text(combo_hwnd)
    _send_key(combo_hwnd, win32con.VK_RETURN)
    if after == value:
        return BackgroundResult(True, "Camfrog CComboBoxTS updated directly in background", combo_hwnd)

    # Some wrappers only consume character messages.
    _send_timeout(combo_hwnd, win32con.WM_SETFOCUS, 0, 0)
    _send_key(combo_hwnd, ord("A"), ctrl=True)
    _send_key(combo_hwnd, win32con.VK_BACK)
    for ch in value:
        _send_timeout(combo_hwnd, win32con.WM_CHAR, ord(ch), 0)
    _send_key(combo_hwnd, win32con.VK_RETURN)
    return BackgroundResult(True, "Camfrog CComboBoxTS commit messages sent in background", combo_hwnd)


def set_status_background(
    parent_hwnd: int,
    relative_x: float,
    relative_y: float,
    value: str,
    *,
    current_text: str = "",
) -> BackgroundResult:
    """Background-first Camfrog status edit without activating/restoring Camfrog."""
    _require_windows()
    if not value:
        return BackgroundResult(False, "Status cannot be empty")
    if not (0.0 <= relative_x <= 1.0 and 0.0 <= relative_y <= 1.0):
        return BackgroundResult(False, "Relative target coordinates must be between 0.0 and 1.0")

    import win32con
    import win32gui

    if not win32gui.IsWindow(parent_hwnd):
        return BackgroundResult(False, "Camfrog window handle is no longer valid")

    try:
        # Reverse-engineered/native route: resource `custom_status_combo` is a
        # CComboBoxTS in this Camfrog build. This avoids coordinate dependence.
        combo = _find_camfrog_status_combo(parent_hwnd, current_text=current_text)
        if combo:
            result = _set_native_combo_text(combo, value)
            if result.ok:
                return result

        # Compatibility route for versions where the native class changes.
        try:
            placement = win32gui.GetWindowPlacement(parent_hwnd)
            normal_left, normal_top, normal_right, normal_bottom = placement[4]
            width = max(1, normal_right - normal_left)
            height = max(1, normal_bottom - normal_top)
            screen_x = int(normal_left + width * relative_x)
            screen_y = int(normal_top + height * relative_y)
        except Exception:
            left, top, right, bottom = win32gui.GetWindowRect(parent_hwnd)
            width = max(1, right - left)
            height = max(1, bottom - top)
            screen_x = int(left + width * relative_x)
            screen_y = int(top + height * relative_y)

        target_hwnd = _smallest_child_at_point(parent_hwnd, screen_x, screen_y)
        edit_hwnd = _find_edit_candidate(target_hwnd)
        if edit_hwnd:
            before = _read_text(edit_hwnd)
            _send_timeout(edit_hwnd, win32con.WM_SETTEXT, 0, value, timeout_ms=1200)
            after = _read_text(edit_hwnd)
            if after == value or (not after and before != value):
                _send_key(edit_hwnd, win32con.VK_RETURN)
                return BackgroundResult(True, "Background status command sent via native Edit", edit_hwnd)

        client_x, client_y = win32gui.ScreenToClient(target_hwnd, (screen_x, screen_y))
        lp = _make_lparam(client_x, client_y)
        _send_timeout(target_hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lp)
        _send_timeout(target_hwnd, win32con.WM_LBUTTONUP, 0, lp)
        _send_timeout(target_hwnd, win32con.WM_SETFOCUS, 0, 0)
        _send_key(target_hwnd, ord("A"), ctrl=True)
        _send_key(target_hwnd, win32con.VK_BACK)
        for ch in value:
            _send_timeout(target_hwnd, win32con.WM_CHAR, ord(ch), 0)
        _send_key(target_hwnd, win32con.VK_RETURN)
        return BackgroundResult(True, "Background status command sent via coordinate compatibility route", target_hwnd)
    except Exception as exc:
        log.exception("Background Win32 automation failed")
        return BackgroundResult(False, f"Background Win32 automation failed: {exc}")
