from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass
from typing import Iterable, Sequence

log = logging.getLogger(__name__)

KNOWN_BASE_KEYS = (
    r"Software\Camfrog\Client",
    r"Software\Camfrog\Client\CurrentVersion",
    r"Software\Camfrog\Client\CurrentVersion\ProfileInfo",
)


@dataclass(frozen=True)
class RegistryStatusResult:
    statuses: list[str]
    sources: list[str]


def _clean_status(value: str) -> str | None:
    value = value.replace("\x00", "").strip()
    if not value or len(value) > 512:
        return None
    # Skip registry/control metadata that is not a user status.
    if value.casefold() in {
        "items", "statevalue", "custom status list", "custom_status_list",
    }:
        return None
    # Avoid importing strings that are mostly control characters.
    printable = sum(ch.isprintable() for ch in value)
    if printable / max(1, len(value)) < 0.90:
        return None
    return value


def _strings_from_binary(data: bytes) -> list[str]:
    out: list[str] = []
    # Camfrog is a Windows Unicode application; try UTF-16LE first.
    for encoding in ("utf-16-le", "utf-8"):
        try:
            text = data.decode(encoding, errors="ignore")
        except Exception:
            continue
        # Accept NUL/newline/pipe/semicolon separated values. The stricter
        # cleaner below removes metadata and junk.
        for part in re.split(r"[\x00\r\n|;]+", text):
            cleaned = _clean_status(part)
            if cleaned:
                out.append(cleaned)
    return out


def extract_status_strings(value, value_type: int | None = None) -> list[str]:
    """Extract user-visible status strings from a registry value.

    Kept independent of winreg so parsing can be regression-tested on any OS.
    """
    values: list[str] = []
    if isinstance(value, (list, tuple)):
        values.extend(str(x) for x in value)
    elif isinstance(value, bytes):
        values.extend(_strings_from_binary(value))
    elif isinstance(value, str):
        text = value.strip()
        # Some versions may serialize lists as JSON.
        if text.startswith("["):
            try:
                parsed = json.loads(text)
                if isinstance(parsed, list):
                    values.extend(str(x) for x in parsed)
                else:
                    values.append(text)
            except Exception:
                values.extend(re.split(r"[\r\n|]+", text))
        else:
            values.extend(re.split(r"[\r\n|]+", text))
    elif value is not None:
        values.append(str(value))

    result: list[str] = []
    seen: set[str] = set()
    for item in values:
        cleaned = _clean_status(item)
        if cleaned and cleaned.casefold() not in seen:
            seen.add(cleaned.casefold())
            result.append(cleaned)
    return result


def merge_presets(existing: Sequence[str], imported: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in [*existing, *list(imported)]:
        cleaned = _clean_status(str(value))
        if not cleaned:
            continue
        key = cleaned.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(cleaned)
    return out


def read_camfrog_custom_statuses(max_depth: int = 6) -> RegistryStatusResult:
    """Read Camfrog custom-status history/presets from HKCU.

    This function is intentionally read-only. It does not touch credentials,
    session data, or write any registry values.
    """
    if os.name != "nt":
        return RegistryStatusResult([], [])

    import winreg

    found: list[str] = []
    sources: list[str] = []
    seen_status: set[str] = set()
    visited: set[tuple[str, int]] = set()

    views = [0]
    for flag_name in ("KEY_WOW64_64KEY", "KEY_WOW64_32KEY"):
        flag = getattr(winreg, flag_name, 0)
        if flag and flag not in views:
            views.append(flag)

    def add_values(path: str, key, view_flag: int) -> None:
        path_l = path.casefold()
        in_custom_key = "custom status" in path_l or "custom_status" in path_l
        value_count = winreg.QueryInfoKey(key)[1]
        for i in range(value_count):
            try:
                name, value, value_type = winreg.EnumValue(key, i)
            except OSError:
                continue
            name_l = (name or "").casefold()
            relevant = (
                in_custom_key
                or "custom status" in name_l
                or "custom_status" in name_l
            )
            # For a known Custom status list subkey, Items/StateValue are also
            # accepted because those names appeared in the inspected binary.
            if not relevant:
                continue
            for status in extract_status_strings(value, value_type):
                marker = status.casefold()
                if marker not in seen_status:
                    seen_status.add(marker)
                    found.append(status)
                    sources.append(f"HKCU\\{path} [{name or '(Default)'}]")

    def walk(path: str, view_flag: int, depth: int) -> None:
        if depth > max_depth:
            return
        token = (path.casefold(), view_flag)
        if token in visited:
            return
        visited.add(token)
        access = winreg.KEY_READ | view_flag
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, access) as key:
                add_values(path, key, view_flag)
                subkey_count = winreg.QueryInfoKey(key)[0]
                for i in range(subkey_count):
                    try:
                        child = winreg.EnumKey(key, i)
                    except OSError:
                        continue
                    child_path = path + "\\" + child
                    # Once under ProfileInfo we need to traverse account/profile
                    # ids. Outside it, keep traversal focused on relevant names.
                    focused = (
                        "profileinfo" in path.casefold()
                        or "custom status" in child.casefold()
                        or "custom_status" in child.casefold()
                    )
                    if focused:
                        walk(child_path, view_flag, depth + 1)
        except (FileNotFoundError, PermissionError, OSError):
            return

    for view in views:
        for base in KNOWN_BASE_KEYS:
            walk(base, view, 0)

    log.info("Read %d Camfrog custom status value(s) from registry", len(found))
    return RegistryStatusResult(found, sources)
