from __future__ import annotations

import json
import logging
import os
import threading
import tkinter as tk
from typing import Optional
from tkinter import filedialog, messagebox

import customtkinter as ctk

from automation.rotation import RotationWorker
from camfrog.controller import CamfrogController
from camfrog.detector import discover_executable
from camfrog.registry_status import merge_presets, read_camfrog_custom_statuses
from system.startup import set_start_with_windows

log = logging.getLogger(__name__)

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("green")


class AppUI(ctk.CTk):
    def __init__(self, store):
        super().__init__()
        self.store = store
        self.config_data = store.load()
        self.controller = CamfrogController(self.config_data)
        self.rotation = RotationWorker(self._apply_status_background)
        self._tray_icon = None
        self._tray_thread: Optional[threading.Thread] = None
        self._exiting = False

        self.title("Camfrog Status Changer")
        self.geometry("760x620")
        self.minsize(720, 560)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self._build()
        self._load_config_to_ui()
        self.after(300, self._auto_detect_if_needed)
        self.after(500, self._start_tray)
        self.after(650, self._auto_import_registry_presets)
        self.after(800, self._resume_background_automation)

    def _build(self):
        root = ctk.CTkScrollableFrame(self)
        root.pack(fill="both", expand=True, padx=14, pady=14)

        ctk.CTkLabel(root, text="Camfrog Status Changer", font=ctk.CTkFont(size=24, weight="bold")).pack(anchor="w", pady=(0, 12))

        self.state_label = ctk.CTkLabel(root, text="Ready")
        self.state_label.pack(anchor="w", pady=(0, 10))

        exe_frame = ctk.CTkFrame(root)
        exe_frame.pack(fill="x", pady=6)
        ctk.CTkLabel(exe_frame, text="Camfrog executable").grid(row=0, column=0, sticky="w", padx=10, pady=(10, 4))
        self.exe_var = tk.StringVar()
        ctk.CTkEntry(exe_frame, textvariable=self.exe_var).grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 10))
        ctk.CTkButton(exe_frame, text="Browse", width=90, command=self._browse).grid(row=1, column=1, padx=(0, 10), pady=(0, 10))
        ctk.CTkButton(exe_frame, text="Detect", width=90, command=self._detect).grid(row=1, column=2, padx=(0, 10), pady=(0, 10))
        exe_frame.grid_columnconfigure(0, weight=1)

        target_frame = ctk.CTkFrame(root)
        target_frame.pack(fill="x", pady=6)
        ctk.CTkLabel(target_frame, text="UI Automation target", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, columnspan=4, sticky="w", padx=10, pady=(10, 4))
        self.control_type_var = tk.StringVar(value="ComboBox")
        self.automation_id_var = tk.StringVar()
        self.title_re_var = tk.StringVar(value=".*")
        ctk.CTkLabel(target_frame, text="Control type").grid(row=1, column=0, sticky="w", padx=10)
        ctk.CTkEntry(target_frame, textvariable=self.control_type_var, width=130).grid(row=2, column=0, padx=10, pady=(0, 10), sticky="w")
        ctk.CTkLabel(target_frame, text="Automation ID (optional)").grid(row=1, column=1, sticky="w", padx=10)
        ctk.CTkEntry(target_frame, textvariable=self.automation_id_var).grid(row=2, column=1, padx=10, pady=(0, 10), sticky="ew")
        ctk.CTkLabel(target_frame, text="Title regex").grid(row=1, column=2, sticky="w", padx=10)
        ctk.CTkEntry(target_frame, textvariable=self.title_re_var).grid(row=2, column=2, padx=10, pady=(0, 10), sticky="ew")
        ctk.CTkButton(target_frame, text="Inspect", command=self._inspect).grid(row=2, column=3, padx=(0, 10), pady=(0, 10))

        self.fallback_x_var = tk.StringVar(value="0.50")
        self.fallback_y_var = tk.StringVar(value="0.19")
        ctk.CTkLabel(target_frame, text="Fallback X (relative)").grid(row=3, column=0, sticky="w", padx=10)
        ctk.CTkEntry(target_frame, textvariable=self.fallback_x_var, width=130).grid(row=4, column=0, padx=10, pady=(0, 10), sticky="w")
        ctk.CTkLabel(target_frame, text="Fallback Y (relative)").grid(row=3, column=1, sticky="w", padx=10)
        ctk.CTkEntry(target_frame, textvariable=self.fallback_y_var).grid(row=4, column=1, padx=10, pady=(0, 10), sticky="ew")
        ctk.CTkButton(target_frame, text="Capture target (3s)", command=self._capture_target).grid(row=4, column=2, columnspan=2, padx=(10, 10), pady=(0, 10), sticky="ew")
        target_frame.grid_columnconfigure(1, weight=1)
        target_frame.grid_columnconfigure(2, weight=1)

        status_frame = ctk.CTkFrame(root)
        status_frame.pack(fill="x", pady=6)
        ctk.CTkLabel(status_frame, text="Set status", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, sticky="w", padx=10, pady=(10, 4))
        self.status_var = tk.StringVar()
        self.status_entry = ctk.CTkEntry(status_frame, textvariable=self.status_var)
        self.status_entry.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 10))
        ctk.CTkButton(status_frame, text="Apply now", command=self._apply_clicked).grid(row=1, column=1, padx=(0, 10), pady=(0, 10))
        status_frame.grid_columnconfigure(0, weight=1)

        preset_frame = ctk.CTkFrame(root)
        preset_frame.pack(fill="x", pady=6)
        preset_header = ctk.CTkFrame(preset_frame, fg_color="transparent")
        preset_header.pack(fill="x", padx=10, pady=(10, 4))
        ctk.CTkLabel(preset_header, text="Presets (one per line)", font=ctk.CTkFont(weight="bold")).pack(side="left")
        ctk.CTkButton(preset_header, text="Read Camfrog Registry", width=155, command=self._read_registry_clicked).pack(side="right")
        self.registry_auto_var = tk.BooleanVar(value=True)
        ctk.CTkCheckBox(preset_frame, text="Import Camfrog custom-status list on startup (read-only)", variable=self.registry_auto_var).pack(anchor="w", padx=10, pady=(0, 6))
        self.presets_box = ctk.CTkTextbox(preset_frame, height=120)
        self.presets_box.pack(fill="x", padx=10, pady=(0, 10))

        auto_frame = ctk.CTkFrame(root)
        auto_frame.pack(fill="x", pady=6)
        self.rotation_var = tk.BooleanVar()
        self.start_windows_var = tk.BooleanVar()
        self.autostart_camfrog_var = tk.BooleanVar()
        self.restore_state_var = tk.BooleanVar(value=True)
        self.background_only_var = tk.BooleanVar(value=True)
        self.foreground_fallback_var = tk.BooleanVar(value=False)
        self.mode_var = tk.StringVar(value="sequential")
        self.interval_var = tk.StringVar(value="10")
        self.interval_unit_var = tk.StringVar(value="minutes")
        ctk.CTkCheckBox(auto_frame, text="Enable status rotation", variable=self.rotation_var).grid(row=0, column=0, sticky="w", padx=10, pady=10)
        ctk.CTkLabel(auto_frame, text="Interval").grid(row=0, column=1, sticky="e")
        ctk.CTkEntry(auto_frame, textvariable=self.interval_var, width=70).grid(row=0, column=2, padx=(10, 4))
        ctk.CTkOptionMenu(auto_frame, values=["minutes", "hours"], variable=self.interval_unit_var, width=100).grid(row=0, column=3, padx=(0, 8))
        ctk.CTkOptionMenu(auto_frame, values=["sequential", "random"], variable=self.mode_var, width=120).grid(row=0, column=4, padx=(0, 10))
        ctk.CTkCheckBox(auto_frame, text="Start with Windows", variable=self.start_windows_var).grid(row=1, column=0, sticky="w", padx=10, pady=(0, 10))
        ctk.CTkCheckBox(auto_frame, text="Start Camfrog if not running", variable=self.autostart_camfrog_var).grid(row=1, column=1, columnspan=2, sticky="w", pady=(0, 10))
        ctk.CTkCheckBox(auto_frame, text="Background only (do not focus/restore Camfrog)", variable=self.background_only_var).grid(row=2, column=0, columnspan=3, sticky="w", padx=10, pady=(0, 6))
        ctk.CTkCheckBox(auto_frame, text="Allow foreground fallback if background fails", variable=self.foreground_fallback_var).grid(row=3, column=0, columnspan=3, sticky="w", padx=10, pady=(0, 10))

        buttons = ctk.CTkFrame(root, fg_color="transparent")
        buttons.pack(fill="x", pady=12)
        ctk.CTkButton(buttons, text="Save settings", command=self._save).pack(side="left", padx=(0, 8))
        ctk.CTkButton(buttons, text="Start rotation", command=self._start_rotation).pack(side="left", padx=8)
        ctk.CTkButton(buttons, text="Stop rotation", command=self._stop_rotation).pack(side="left", padx=8)
        ctk.CTkButton(buttons, text="Open config folder", command=self._open_config_dir).pack(side="right")

    def _load_config_to_ui(self):
        c = self.config_data
        self.exe_var.set(c["camfrog"].get("executable", ""))
        self.control_type_var.set(c["target"].get("control_type", "ComboBox"))
        self.automation_id_var.set(c["target"].get("automation_id", ""))
        self.title_re_var.set(c["target"].get("title_regex", ".*"))
        self.fallback_x_var.set(str(c["target"].get("fallback_relative_x", 0.50)))
        self.fallback_y_var.set(str(c["target"].get("fallback_relative_y", 0.19)))
        self.rotation_var.set(bool(c["status"]["rotation"].get("enabled", False)))
        interval_seconds = int(c["status"]["rotation"].get("interval_seconds", 600))
        if interval_seconds >= 3600 and interval_seconds % 3600 == 0:
            self.interval_var.set(str(interval_seconds // 3600))
            self.interval_unit_var.set("hours")
        else:
            self.interval_var.set(str(max(1, interval_seconds // 60)))
            self.interval_unit_var.set("minutes")
        self.mode_var.set(c["status"]["rotation"].get("mode", "sequential"))
        self.start_windows_var.set(bool(c["startup"].get("windows_startup", False)))
        self.autostart_camfrog_var.set(bool(c["camfrog"].get("auto_start", False)))
        self.restore_state_var.set(bool(c["camfrog"].get("restore_window_state", True)))
        self.background_only_var.set(bool(c.get("advanced", {}).get("background_only", True)))
        self.foreground_fallback_var.set(bool(c.get("advanced", {}).get("fallback_enabled", False)))
        self.registry_auto_var.set(bool(c.get("registry", {}).get("import_presets_on_start", True)))
        self.presets_box.delete("1.0", "end")
        self.presets_box.insert("1.0", "\n".join(c["status"].get("presets", [])))
        presets = c["status"].get("presets", [])
        if presets:
            self.status_var.set(presets[0])

    def _sync_ui_to_config(self):
        c = self.config_data
        c["camfrog"]["executable"] = self.exe_var.get().strip()
        c["camfrog"]["auto_start"] = bool(self.autostart_camfrog_var.get())
        c["camfrog"]["restore_window_state"] = bool(self.restore_state_var.get())
        c.setdefault("advanced", {})["background_only"] = bool(self.background_only_var.get())
        c["advanced"]["fallback_enabled"] = bool(self.foreground_fallback_var.get())
        c.setdefault("target", {})["background_enabled"] = True
        c["target"]["control_type"] = self.control_type_var.get().strip() or "ComboBox"
        c["target"]["automation_id"] = self.automation_id_var.get().strip()
        c["target"]["title_regex"] = self.title_re_var.get().strip() or ".*"
        try:
            fx = float(self.fallback_x_var.get().strip())
            fy = float(self.fallback_y_var.get().strip())
        except ValueError:
            fx, fy = 0.50, 0.19
        c["target"]["fallback_relative_x"] = min(1.0, max(0.0, fx))
        c["target"]["fallback_relative_y"] = min(1.0, max(0.0, fy))
        presets = [x.strip() for x in self.presets_box.get("1.0", "end").splitlines() if x.strip()]
        c["status"]["presets"] = presets
        c["status"]["rotation"]["enabled"] = bool(self.rotation_var.get())
        try:
            amount = max(1, int(self.interval_var.get().strip()))
        except ValueError:
            amount = 10
        unit = self.interval_unit_var.get()
        interval = amount * (3600 if unit == "hours" else 60)
        interval = max(60, interval)
        c["status"]["rotation"]["interval_seconds"] = interval
        c["status"]["rotation"]["mode"] = self.mode_var.get()
        c["startup"]["windows_startup"] = bool(self.start_windows_var.get())
        c.setdefault("registry", {})["import_presets_on_start"] = bool(self.registry_auto_var.get())
        self.controller.config = c
        return c


    def _auto_import_registry_presets(self):
        if not self.registry_auto_var.get():
            return
        self._read_registry_presets(silent=True)

    def _read_registry_clicked(self):
        self._read_registry_presets(silent=False)

    def _read_registry_presets(self, silent: bool = False):
        if os.name != "nt":
            if not silent:
                messagebox.showwarning("Camfrog Registry", "Registry import is available on Windows only.")
            return
        self.state_label.configure(text="Reading Camfrog custom statuses from Registry...")
        threading.Thread(target=self._registry_worker, args=(silent,), daemon=True).start()

    def _registry_worker(self, silent: bool):
        try:
            result = read_camfrog_custom_statuses()
            self.after(0, lambda: self._registry_import_done(result, silent))
        except Exception as exc:
            log.exception("Registry status import failed")
            self.after(0, lambda exc=exc: self._registry_import_failed(exc, silent))

    def _registry_import_done(self, result, silent: bool):
        current = [x.strip() for x in self.presets_box.get("1.0", "end").splitlines() if x.strip()]
        merged = merge_presets(current, result.statuses)
        added = len(merged) - len(merge_presets(current, []))
        self.presets_box.delete("1.0", "end")
        self.presets_box.insert("1.0", "\n".join(merged))
        self.config_data["status"]["presets"] = merged
        self.store.save(self.config_data)
        if result.statuses:
            self.state_label.configure(text=f"Registry: imported {added} new preset(s); {len(result.statuses)} value(s) found")
            if not silent:
                sample_sources = "\n".join(result.sources[:5])
                messagebox.showinfo("Camfrog Registry", f"Found {len(result.statuses)} custom status value(s).\nAdded {added} new preset(s).\n\nSources:\n{sample_sources}")
        else:
            self.state_label.configure(text="Registry: no Camfrog custom status list found")
            if not silent:
                messagebox.showinfo("Camfrog Registry", "No custom-status values were found under the known Camfrog registry paths.")

    def _registry_import_failed(self, exc: Exception, silent: bool):
        self.state_label.configure(text=f"Registry read error: {exc}")
        if not silent:
            messagebox.showerror("Camfrog Registry", str(exc))

    def _auto_detect_if_needed(self):
        if not self.exe_var.get().strip():
            self._detect(silent=True)

    def _browse(self):
        path = filedialog.askopenfilename(filetypes=[("Executable", "*.exe"), ("All files", "*.*")])
        if path:
            self.exe_var.set(path)

    def _detect(self, silent=False):
        path = discover_executable()
        if path:
            self.exe_var.set(path)
            self.state_label.configure(text=f"Detected: {path}")
        elif not silent:
            messagebox.showwarning("Camfrog", "Camfrog executable/process was not detected. Use Browse to select Camfrog.exe.")

    def _save(self):
        c = self._sync_ui_to_config()
        self.store.save(c)
        try:
            set_start_with_windows(c["startup"]["windows_startup"])
        except Exception as exc:
            messagebox.showwarning("Startup", f"Settings saved, but Windows startup could not be updated:\n{exc}")
            return
        self.state_label.configure(text="Settings saved")

    def _apply_clicked(self):
        self._sync_ui_to_config()
        value = self.status_var.get().strip()
        if not value:
            messagebox.showwarning("Status", "Enter a status first.")
            return
        self.state_label.configure(text="Changing status...")
        threading.Thread(target=self._apply_worker, args=(value,), daemon=True).start()

    def _apply_worker(self, value):
        result = self.controller.set_status(value)
        self.after(0, lambda: self._show_result(result))

    def _apply_status_background(self, value):
        result = self.controller.set_status(value)
        self.after(0, lambda: self.state_label.configure(text=result.message if result.ok else f"ERROR: {result.message}"))

    def _show_result(self, result):
        self.state_label.configure(text=result.message if result.ok else f"ERROR: {result.message}")
        if not result.ok:
            messagebox.showerror("Camfrog Status", result.message)

    def _start_rotation(self):
        c = self._sync_ui_to_config()
        presets = c["status"]["presets"]
        if not presets:
            messagebox.showwarning("Rotation", "Add at least one preset.")
            return
        interval = c["status"]["rotation"]["interval_seconds"]
        self.rotation.start(presets, interval, c["status"]["rotation"]["mode"])
        self.rotation_var.set(True)
        c["status"]["rotation"]["enabled"] = True
        self.store.save(c)
        self.state_label.configure(text=f"Rotation started; first change in {self._format_interval(interval)}")


    @staticmethod
    def _format_interval(seconds: int) -> str:
        if seconds % 3600 == 0:
            return f"{seconds // 3600} hour(s)"
        return f"{max(1, seconds // 60)} minute(s)"

    def _stop_rotation(self):
        self.rotation.stop()
        self.rotation_var.set(False)
        self.config_data["status"]["rotation"]["enabled"] = False
        self.store.save(self.config_data)
        self.state_label.configure(text="Rotation stopped")


    def _capture_target(self):
        self._sync_ui_to_config()
        self._capture_countdown = 3
        self._capture_tick()

    def _capture_tick(self):
        if self._capture_countdown > 0:
            self.state_label.configure(
                text=f"Move mouse over Camfrog status field — capturing in {self._capture_countdown}s..."
            )
            self._capture_countdown -= 1
            self.after(1000, self._capture_tick)
            return

        self.state_label.configure(text="Capturing target...")
        threading.Thread(target=self._capture_target_worker, daemon=True).start()

    def _capture_target_worker(self):
        try:
            if os.name != "nt":
                raise RuntimeError("Target capture is available on Windows only")
            import win32api

            # pywinauto enumeration can be slow for custom-rendered applications;
            # keep it off the Tk UI thread so Windows never marks the app hung.
            win = self.controller.find_window()
            rect = win.rectangle()
            x, y = win32api.GetCursorPos()
            if not (rect.left <= x <= rect.right and rect.top <= y <= rect.bottom):
                raise RuntimeError("Mouse cursor is not over the Camfrog window")
            rx = (x - rect.left) / max(1, rect.width())
            ry = (y - rect.top) / max(1, rect.height())
            self.after(0, lambda: self._capture_target_success(rx, ry))
        except Exception as exc:
            self.after(0, lambda exc=exc: self._capture_target_failed(exc))

    def _capture_target_success(self, rx: float, ry: float):
        self.fallback_x_var.set(f"{rx:.4f}")
        self.fallback_y_var.set(f"{ry:.4f}")
        self._sync_ui_to_config()
        self.store.save(self.config_data)
        self.state_label.configure(text=f"Captured fallback target X={rx:.4f}, Y={ry:.4f}")
        messagebox.showinfo("Target captured", "Fallback target saved. You can now test with Apply now.")

    def _capture_target_failed(self, exc: Exception):
        self.state_label.configure(text=f"ERROR: {exc}")
        messagebox.showerror("Capture failed", str(exc))

    def _inspect(self):
        self._sync_ui_to_config()
        self.state_label.configure(text="Inspecting Camfrog controls...")
        threading.Thread(target=self._inspect_worker, daemon=True).start()

    def _inspect_worker(self):
        try:
            result = self.controller.ensure_running()
            if not result.ok:
                raise RuntimeError(result.message)
            controls = self.controller.inspect_controls()
            interesting = [x for x in controls if x["control_type"] in {"ComboBox", "Edit", "Text"} and (x["title"] or x["automation_id"])]
            payload = json.dumps(interesting[:100], indent=2, ensure_ascii=False)
            path = self.store.dir / "uia-controls.json"
            path.write_text(payload, encoding="utf-8")
            self.after(0, lambda: messagebox.showinfo("Inspect complete", f"Saved {len(interesting)} candidate controls to:\n{path}"))
            self.after(0, lambda: self.state_label.configure(text="Inspect complete"))
        except Exception as exc:
            self.after(0, lambda: messagebox.showerror("Inspect failed", str(exc)))
            self.after(0, lambda: self.state_label.configure(text=f"ERROR: {exc}"))

    def _open_config_dir(self):
        self.store.dir.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(self.store.dir)  # type: ignore[attr-defined]
        else:
            messagebox.showinfo("Config folder", str(self.store.dir))

    def _resume_background_automation(self):
        c = self.config_data
        if c.get("status", {}).get("rotation", {}).get("enabled", False):
            presets = c.get("status", {}).get("presets", [])
            if presets:
                interval = max(30, int(c["status"]["rotation"].get("interval_seconds", 300)))
                mode = c["status"]["rotation"].get("mode", "sequential")
                self.rotation.start(presets, interval, mode)
                self.state_label.configure(text=f"Background rotation active; next change in {self._format_interval(interval)}")
        if c.get("startup", {}).get("start_minimized", False):
            self.withdraw()

    def _start_tray(self):
        if os.name != "nt" or self._tray_icon is not None:
            return
        try:
            import pystray
            from PIL import Image, ImageDraw

            image = Image.new("RGB", (64, 64), "black")
            draw = ImageDraw.Draw(image)
            draw.ellipse((8, 8, 56, 56), outline="white", width=5)
            draw.text((23, 18), "C", fill="white")

            menu = pystray.Menu(
                pystray.MenuItem("Open", lambda icon, item: self.after(0, self._show_from_tray)),
                pystray.MenuItem("Pause rotation", lambda icon, item: self.after(0, self._stop_rotation)),
                pystray.MenuItem("Exit", lambda icon, item: self.after(0, self._exit_app)),
            )
            self._tray_icon = pystray.Icon("CamfrogStatusChanger", image, "Camfrog Status Changer", menu)
            self._tray_thread = threading.Thread(target=self._tray_icon.run, daemon=True)
            self._tray_thread.start()
        except Exception:
            log.exception("Could not start system tray")

    def _show_from_tray(self):
        self.deiconify()
        self.lift()

    def _exit_app(self):
        self._exiting = True
        self.rotation.stop()
        if self._tray_icon is not None:
            try:
                self._tray_icon.stop()
            except Exception:
                pass
        self.destroy()

    def _on_close(self):
        # Closing the control panel keeps automation running in the tray.
        if self._exiting:
            self._exit_app()
            return
        self.withdraw()
