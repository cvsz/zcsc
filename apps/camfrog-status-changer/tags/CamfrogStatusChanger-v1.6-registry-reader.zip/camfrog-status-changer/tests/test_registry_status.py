from camfrog.registry_status import extract_status_strings, merge_presets


def test_extract_multiline_and_dedupe():
    assert extract_status_strings("Sea THAIFIGHT\nBusy\nsea thaifight") == ["Sea THAIFIGHT", "Busy"]


def test_extract_json_list():
    assert extract_status_strings('["One", "Two", "One"]') == ["One", "Two"]


def test_merge_preserves_existing_order():
    assert merge_presets(["Busy", "Available"], ["busy", "Sea THAIFIGHT"]) == [
        "Busy", "Available", "Sea THAIFIGHT"
    ]
