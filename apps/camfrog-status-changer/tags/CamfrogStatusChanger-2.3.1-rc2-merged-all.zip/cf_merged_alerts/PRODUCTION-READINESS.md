# Camfrog Status Changer — Production Readiness

Version: 2.3.0-rc1

## Verified in this package

- Source compiles successfully on the build environment.
- Automated regression suite passes (17 tests).
- Configuration writes are atomic (`config.tmp` + `os.replace`).
- Corrupt configuration is backed up and automatically recovered to safe defaults.
- Single-instance Windows mutex prevents duplicate tray/background workers.
- Manual and scheduled status changes share a non-blocking apply lock.
- Minimum apply interval rate-limits accidental rapid status changes.
- Background-only is the default; foreground mouse/clipboard fallback is opt-in.
- Native background changes only report success when the target control value is verified.
- Registry import is read-only and filters numeric, account-like, opaque/binary and sensitive-key data.
- Logs rotate at 2 MiB with five backups rather than growing without bound.
- Windows startup uses HKCU Run and `pythonw.exe` in source mode to avoid a console window.
- Build gate runs tests and compile checks before creating the EXE.
- Release build generates SHA-256/size metadata in `release-manifest.json`.
- Unused APScheduler and keyboard dependencies were removed.

## P0 release gates requiring a real Windows + Camfrog run

These cannot be honestly certified from a Linux/container build environment:

1. Verify `Apply now` changes the server-visible Camfrog custom status, not only local control text.
2. Verify the same status change while Camfrog is minimized and not focused.
3. Verify status survives/reconciles after Camfrog reconnect/login refresh.
4. Verify sequential and random rotation for at least 10 cycles at 5–10 second test intervals, then normal intervals.
5. Verify no foreground focus/mouse movement occurs in Background-only mode.
6. Verify Camfrog update/restart does not change `CComboBoxTS` targeting unexpectedly.
7. Build EXE on Windows and verify manifest SHA-256 matches the artifact.
8. Test Windows startup, tray close/reopen, single-instance behavior, log rotation, and clean exit.
9. Scan final EXE with Windows Defender and organizational malware scanning policy; do not bypass detections with exclusions.
10. Confirm Camfrog terms/policies permit the intended automation before broad distribution.

## Acceptance criteria

Production-ready may be claimed only after every P0 gate above has timestamped evidence. A passing unit-test suite alone is not production evidence.

## Recommended evidence bundle

Store under `evidence/<YYYYMMDD-HHMMSS>/`:

- `self-test.json`
- `camfrog-native-controls-safe.json`
- redacted `app.log`
- screenshots/video showing before/after status from another Camfrog account if possible
- `release-manifest.json`
- Windows Defender scan result
- exact Camfrog version and executable SHA-256

## Native reverse-engineering gate (2.1.0-rc1)

- [x] Exact known Camfrog binary SHA-256 profile recorded.
- [x] Known native UI classes used for targeting/commit scoring.
- [x] Status-related RE RVAs recorded as diagnostics only.
- [x] Unknown Camfrog binary versions fail back to generic UI/Win32 path; no internal function invocation.
- [ ] Dynamic trace proves the exact UI commit -> ChangeStatus -> SetSelfStatus -> protobuf serializer chain.
- [ ] ABI/object lifetime for any proposed internal call is proven before enabling a direct native adapter.
- [ ] Remote-account E2E confirms the server-visible custom status after a background change.


## Detect preferred executable

The Detect action first checks `%LOCALAPPDATA%\Programs\Camfrog Video Chat\Camfrog Video Chat.exe`, then falls back to running-process discovery and legacy Program Files locations.

### 2.2.3-rc5 acceptance additions
- [x] Four independent message slots; no multiline compose across slots.
- [x] One scheduler tick invokes one status apply only.
- [x] Legacy `editor_lines` migrates to Message 1/2 without joining the values.
- [x] TH/EN covers main UI and automation option values.
- [x] Random Color/Marquee style exactly one outgoing message per tick.


### 2.3.0-rc1 audit gates
- [x] Ctrl+V source-level double-paste root cause removed.
- [x] Style checkbox callback method exists and is tested.
- [x] Unsupported custom-status color markup removed.
- [x] Marquee frames avoid leading-space dependency.
- [x] Per-message marquee phase.
- [x] Rotation exceptions logged.
- [ ] Windows packaged-EXE clipboard E2E.
- [ ] Server-visible marquee E2E.
- [ ] Unicode color-marker rendering E2E.
