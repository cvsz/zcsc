from pathlib import Path
import camfrog.detector as detector


def test_preferred_path_wins(monkeypatch, tmp_path):
    preferred = tmp_path / 'Camfrog Video Chat.exe'
    preferred.write_bytes(b'MZ')
    monkeypatch.setattr(detector, 'PREFERRED_PATH', preferred)
    monkeypatch.setattr(detector, 'KNOWN_PATHS', [preferred])
    monkeypatch.setattr(detector, 'find_processes', lambda: (_ for _ in ()).throw(AssertionError('process scan should not run')))
    assert detector.discover_executable() == str(preferred)


def test_process_fallback_when_preferred_missing(monkeypatch, tmp_path):
    preferred = tmp_path / 'missing.exe'
    monkeypatch.setattr(detector, 'PREFERRED_PATH', preferred)
    monkeypatch.setattr(detector, 'KNOWN_PATHS', [preferred])

    class P:
        def exe(self):
            return r'C:\\Other\\Camfrog Video Chat.exe'

    monkeypatch.setattr(detector, 'find_processes', lambda: [P()])
    assert detector.discover_executable() == r'C:\\Other\\Camfrog Video Chat.exe'
