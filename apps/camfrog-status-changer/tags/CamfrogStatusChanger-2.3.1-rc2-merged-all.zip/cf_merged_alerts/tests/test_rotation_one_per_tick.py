import time
from automation.rotation import RotationWorker


def test_rotation_changes_exactly_one_preset_per_tick():
    seen=[]
    w=RotationWorker(seen.append)
    w.start(["one","two","three"], 1, "sequential")
    time.sleep(1.15)
    w.stop()
    assert seen == ["one"]


def test_rotation_restart_resets_to_first_preset():
    seen=[]
    w=RotationWorker(seen.append)
    w.start(["one","two"], 1, "sequential")
    time.sleep(1.15)
    w.stop()
    w.start(["one","two"], 1, "sequential")
    time.sleep(1.15)
    w.stop()
    assert seen == ["one", "one"]
