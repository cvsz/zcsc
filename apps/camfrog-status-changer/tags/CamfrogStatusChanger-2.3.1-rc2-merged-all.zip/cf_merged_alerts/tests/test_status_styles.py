from status_styles import marquee_frame, apply_styles, random_color


def test_marquee_one_frame_per_call_without_leading_padding():
    a, n = marquee_frame("HELLO", 0, 8)
    b, n2 = marquee_frame("HELLO", n, 8)
    assert a != b
    assert not a.startswith(" ")
    assert not b.startswith(" ")
    assert n2 == 2


def test_marquee_preserves_lines():
    v, n = marquee_frame("A\r\nB", 0, 8)
    assert v == "A\r\nB"
    assert n == 1


def test_random_color_uses_plain_text_marker_not_markup():
    v, _, color = apply_styles("HELLO", random_color_enabled=True, palette=["🔵"])
    assert v == "🔵 HELLO"
    assert color == "🔵"
    assert "[color=" not in v


def test_legacy_hex_palette_does_not_emit_unsupported_markup():
    v, _, color = apply_styles("HELLO", random_color_enabled=True, palette=["#ABCDEF"])
    assert v.endswith(" HELLO")
    assert color != "#ABCDEF"
    assert "[color=" not in v


def test_style_disabled_is_identity():
    v, n, color = apply_styles("HELLO", random_color_enabled=False, marquee_enabled=False)
    assert v == "HELLO"
    assert n == 0
    assert color is None
