from __future__ import annotations

import copy
import json
import os
import shutil
import time
from pathlib import Path
from typing import Any

DEFAULT_CONFIG = {
    "schema_version": 2,
    "camfrog": {
        "executable": "",
        "window_title_regex": ".*Camfrog Video Chat.*",
        "auto_start": False,
        "restore_window_state": True,
    },
    "target": {
        "control_type": "ComboBox",
        "automation_id": "",
        "title_regex": ".*",
        "fallback_relative_x": 0.50,
        "fallback_relative_y": 0.19,
        "background_enabled": True,
    },
    "status": {
        "presets": ["Sea THAIFIGHT", "ZEAZDEV COMPANY LIMITED"],
        "editor_messages": ["Sea THAIFIGHT", "ZEAZDEV COMPANY LIMITED", "Busy", "Available"],
         "rotation": {"enabled": False, "interval_seconds": 600, "mode": "sequential"},
        "styles": {
            "random_color": False,
            "marquee": False,
            "marquee_width": 28,
            "color_template": "[color={color}]{text}[/color]",
            "palette": ["🔴","🟠","🟡","🟢","🔵","🟣","🟤","⚪"]
        },
    },
    "startup": {"windows_startup": False, "start_minimized": False, "system_tray": True},
    "registry": {"import_presets_on_start": True},
    "ui": {"language": "EN"},
    "advanced": {
        "minimum_interval_seconds": 5,
        "fallback_enabled": False,
        "background_only": True,
        "max_status_length": 160,
        "apply_timeout_seconds": 8,
    },
}


class ConfigStore:
    def __init__(self) -> None:
        appdata = os.getenv("APPDATA")
        base = Path(appdata) if appdata else (Path.home() / ".config")
        self.dir = base / "CamfrogStatusChanger"
        self.path = self.dir / "config.json"

    def ensure_defaults(self) -> None:
        self.dir.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.save(copy.deepcopy(DEFAULT_CONFIG))

    def load(self) -> dict[str, Any]:
        self.ensure_defaults()
        try:
            with self.path.open("r", encoding="utf-8") as f:
                raw = json.load(f)
            if not isinstance(raw, dict):
                raise ValueError("config root must be an object")
            return self.validate(self._merge(DEFAULT_CONFIG, raw))
        except Exception:
            stamp = time.strftime("%Y%m%d-%H%M%S")
            backup = self.dir / f"config.corrupt-{stamp}.json"
            try:
                shutil.copy2(self.path, backup)
            except Exception:
                pass
            clean = copy.deepcopy(DEFAULT_CONFIG)
            self.save(clean)
            return clean

    def save(self, data: dict[str, Any]) -> None:
        data = self.validate(self._merge(DEFAULT_CONFIG, data))
        self.dir.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8", newline="\n") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, self.path)

    @staticmethod
    def validate(data: dict[str, Any]) -> dict[str, Any]:
        data["schema_version"] = 2
        adv = data.setdefault("advanced", {})
        adv["minimum_interval_seconds"] = max(5, int(adv.get("minimum_interval_seconds", 5)))
        adv["max_status_length"] = min(512, max(1, int(adv.get("max_status_length", 160))))
        adv["apply_timeout_seconds"] = min(30, max(2, int(adv.get("apply_timeout_seconds", 8))))
        rot = data.setdefault("status", {}).setdefault("rotation", {})
        rot["interval_seconds"] = max(adv["minimum_interval_seconds"], int(rot.get("interval_seconds", 600)))
        if rot.get("mode") not in {"sequential", "random"}:
            rot["mode"] = "sequential"
        presets = data["status"].setdefault("presets", [])
        clean = []
        seen = set()
        for item in presets:
            value = str(item).replace("\x00", "").strip()[: adv["max_status_length"]]
            key = value.casefold()
            if value and key not in seen:
                seen.add(key)
                clean.append(value)
        data["status"]["presets"] = clean
        # Message slots are independent statuses: one message = one apply/tick.
        messages = data["status"].get("editor_messages")
        if not isinstance(messages, list):
            legacy = data["status"].get("editor_lines", [])
            messages = legacy if isinstance(legacy, list) else [legacy]
        messages = [str(x).replace("\x00", "").strip()[: adv["max_status_length"]] for x in messages[:4]]
        messages += [""] * (4 - len(messages))
        data["status"]["editor_messages"] = messages
        data["status"].pop("editor_lines", None)
        styles = data["status"].setdefault("styles", {})
        styles["random_color"] = bool(styles.get("random_color", False))
        styles["marquee"] = bool(styles.get("marquee", False))
        styles["marquee_width"] = min(80, max(4, int(styles.get("marquee_width", 28))))
        styles["color_template"] = str(styles.get("color_template", "[color={color}]{text}[/color]"))[:200]
        palette = styles.get("palette", [])
        if not isinstance(palette, list):
            palette = []
        cleaned_palette = [str(x).strip()[:16] for x in palette if str(x).strip()][:32]
        if not cleaned_palette or all(x.startswith("#") for x in cleaned_palette):
            cleaned_palette = ["🔴","🟠","🟡","🟢","🔵","🟣","🟤","⚪"]
        styles["palette"] = cleaned_palette
        ui = data.setdefault("ui", {})
        ui["language"] = "TH" if str(ui.get("language", "EN")).upper() == "TH" else "EN"
        target = data.setdefault("target", {})
        for key, default in (("fallback_relative_x", .5), ("fallback_relative_y", .19)):
            try:
                target[key] = min(1.0, max(0.0, float(target.get(key, default))))
            except Exception:
                target[key] = default
        return data

    @staticmethod
    def _merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        out = copy.deepcopy(base)
        for k, v in override.items():
            if isinstance(v, dict) and isinstance(out.get(k), dict):
                out[k] = ConfigStore._merge(out[k], v)
            else:
                out[k] = v
        return out
