# Camfrog Status Changer — Deep Audit 2.3.0-rc1

## Scope

Audited the 2.2.4-rc6 source tree with emphasis on clipboard behavior, status styles, scheduler semantics, UI localization, Windows packaging, and operational diagnostics.

## Fixed defects

### P0/P1

1. **Ctrl+V duplicated pasted text** — root cause was `bind_all(..., add="+")` plus an extra `<<Paste>>` event. Tk's normal class binding could paste once before the app-generated virtual event pasted again. Replaced with single-shot class bindings and direct clipboard insertion.
2. **Style checkbox callback crashed** — `_style_changed()` called `_refresh_status_preview()` but that method did not exist. Added a real preview method and persistence path.
3. **Random Color emitted unsupported markup** — `[color=#RRGGBB]...[/color]` was not supported by current Camfrog custom-status documentation. It is now a plain-text **Random Color Marker** using Unicode colored markers; no fake font-color claim is made.
4. **Marquee depended on leading spaces** — Camfrog/custom controls can trim whitespace, making frames appear static. Marquee now uses cyclic text rotation without leading padding.
5. **Marquee offset leaked across messages** — one global offset caused Message 2 to inherit Message 1's animation phase. Offsets are now maintained per message value.

### P2 / operational

6. **Rotation failures were silently swallowed** — exceptions now go to `app.log` while the worker stays alive.
7. **TH title could revert to English after startup** — `app.py` overwrote the localized window title after `AppUI` initialized. Window title now preserves TH/EN plus version.
8. **Tray icon ignored the bundled Z icon** — tray now loads `app.ico` when available and falls back only if unavailable.
9. **Stale docs/version labels** — release docs updated for 2.3.0-rc1 semantics.

## Camfrog capability finding

Current public Camfrog documentation describes custom status as text in the "What's hopping" field. It does not document HTML/BBCode font-color or `<marquee>` support for custom status. Camfrog does expose separate nickname-color/profile features, and historical room/IM text color settings exist, but those are different data paths.

Therefore:

- **Actual custom-status font color:** not claimed as supported.
- **Random Color Marker:** supported by this app as plain text (for example `🔵 HELLO`) and requires only Unicode rendering.
- **Marquee:** simulated by changing one plain-text frame per scheduler tick. It is not an HTML marquee.
- **1 tick = 1 message = 1 call to `set_status()`** remains enforced.

## Verification completed in this environment

- Python compile check
- Full regression suite
- Self-method call audit on `AppUI`
- Config migration tests
- One-message-per-tick tests
- Clipboard source regression (no `bind_all` / no generated paste event)
- Style transformation tests

## Gates requiring Windows + Camfrog E2E

- Verify Ctrl+C/X/V/A in packaged Windows EXE.
- Verify Unicode color marker renders in Camfrog/contact list.
- Verify marquee frame changes are server-visible at configured intervals.
- Verify background status commit after Camfrog updates.
- Verify system tray icon from the one-file PyInstaller artifact.
10. **Tray icon missing in PyInstaller one-file runtime** — `--icon` changes the executable resource but does not expose `app.ico` under `_MEIPASS`. Both build scripts now also include `--add-data=app.ico;.` so the tray can load the supplied icon.
