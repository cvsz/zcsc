from __future__ import annotations

import logging
from tkinter import messagebox

from system.config_store import ConfigStore
from system.logging_setup import configure_logging
from system.single_instance import SingleInstance
from ui.dashboard import AppUI
from version import APP_NAME, VERSION


def main() -> int:
    configure_logging()
    log = logging.getLogger("camfrog_status")
    instance = SingleInstance()
    if not instance.acquire():
        try:
            messagebox.showinfo(APP_NAME, "Camfrog Status Changer is already running. Check the system tray.")
        except Exception:
            pass
        return 2
    try:
        store = ConfigStore()
        store.ensure_defaults()
        app = AppUI(store=store)
        app.title(f"{APP_NAME} {VERSION}")
        app.mainloop()
        return 0
    except Exception:
        log.exception("Fatal application error")
        try:
            messagebox.showerror(APP_NAME, "The application encountered a fatal error. See app.log in the config folder.")
        except Exception:
            pass
        return 1
    finally:
        instance.release()


if __name__ == "__main__":
    raise SystemExit(main())
