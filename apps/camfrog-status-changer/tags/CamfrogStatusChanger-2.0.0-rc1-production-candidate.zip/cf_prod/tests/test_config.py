import tempfile
from pathlib import Path

from system.config_store import ConfigStore, DEFAULT_CONFIG


def test_merge_preserves_defaults():
    merged = ConfigStore._merge(DEFAULT_CONFIG, {"camfrog": {"auto_start": True}})
    assert merged["camfrog"]["auto_start"] is True
    assert "window_title_regex" in merged["camfrog"]
    assert merged["target"]["control_type"] == "ComboBox"
