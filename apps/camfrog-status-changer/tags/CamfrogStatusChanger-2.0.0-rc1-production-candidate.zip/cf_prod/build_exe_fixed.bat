@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Camfrog Status Changer - Production Candidate Build
set "APP=CamfrogStatusChanger"
set "OLD_DIST=%CD%\dist"
set "NEW_DIST=%CD%\dist-new"
set "WORK=%CD%\build"
set "SPEC=%CD%\%APP%.spec"

echo ==================================================
echo Camfrog Status Changer - Production Candidate Build
echo ==================================================
where py >nul 2>&1 || (echo [ERROR] Python launcher not found.& exit /b 1)

echo [1/9] Closing running app instances...
taskkill /F /IM "%APP%.exe" >nul 2>&1
for /L %%I in (1,1,15) do (
  tasklist /FI "IMAGENAME eq %APP%.exe" 2>NUL | find /I "%APP%.exe" >NUL
  if errorlevel 1 goto :released
  >nul timeout /t 1 /nobreak
)
:released

echo [2/9] Installing deterministic dependencies...
py -m pip install -r requirements.txt pytest pyinstaller
if errorlevel 1 goto :failed

echo [3/9] Running regression tests...
set "PYTHONPATH=%CD%"
py -m pytest -q
if errorlevel 1 goto :failed

echo [4/9] Running source compile check...
py -m compileall -q app.py automation camfrog system ui version.py self_test.py
if errorlevel 1 goto :failed

echo [5/9] Checking old artifact lock...
if exist "%OLD_DIST%\%APP%.exe" (
  del /F /Q "%OLD_DIST%\%APP%.exe" >nul 2>&1
  if exist "%OLD_DIST%\%APP%.exe" (
    echo [ERROR] Existing EXE is still locked: "%OLD_DIST%\%APP%.exe"
    goto :failed
  )
)

echo [6/9] Cleaning isolated staging directories...
if exist "%NEW_DIST%" rmdir /S /Q "%NEW_DIST%"
if exist "%WORK%" rmdir /S /Q "%WORK%"
if exist "%SPEC%" del /F /Q "%SPEC%"
mkdir "%NEW_DIST%" >nul 2>&1

echo [7/9] Building windowed one-file EXE...
set "ICON_ARG="
if exist "%CD%\app.ico" set "ICON_ARG=--icon=%CD%\app.ico"
py -m PyInstaller --clean --noconfirm --onefile --windowed --name "%APP%" --distpath "%NEW_DIST%" --workpath "%WORK%" %ICON_ARG% app.py
if errorlevel 1 goto :failed
if not exist "%NEW_DIST%\%APP%.exe" (echo [ERROR] Expected EXE not generated.& goto :failed)

echo [8/9] Publishing artifact...
if not exist "%OLD_DIST%" mkdir "%OLD_DIST%"
copy /Y "%NEW_DIST%\%APP%.exe" "%OLD_DIST%\%APP%.exe" >nul
if errorlevel 1 goto :failed
powershell -NoProfile -ExecutionPolicy Bypass -File "%CD%\release_manifest.ps1"
if errorlevel 1 goto :failed

echo [9/9] Cleaning staging output...
rmdir /S /Q "%NEW_DIST%" >nul 2>&1

echo.
echo BUILD SUCCESS
echo EXE:      "%OLD_DIST%\%APP%.exe"
echo Manifest: "%OLD_DIST%\release-manifest.json"
exit /b 0

:failed
echo.
echo BUILD FAILED - existing published artifact was not considered validated.
exit /b 1
