from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from typing import Iterable

log = logging.getLogger(__name__)


@dataclass
class BackgroundResult:
    ok: bool
    message: str
    hwnd: int = 0
    verified: bool = False
    observed_value: str = ""


def _require_windows() -> None:
    if os.name != "nt":
        raise RuntimeError("Win32 background automation is available on Windows only")


def _make_lparam(x: int, y: int) -> int:
    return ((y & 0xFFFF) << 16) | (x & 0xFFFF)


def _make_wparam(low: int, high: int) -> int:
    return (low & 0xFFFF) | ((high & 0xFFFF) << 16)


def _send_timeout(hwnd: int, msg: int, wparam=0, lparam=0, timeout_ms: int = 800):
    import win32con
    import win32gui
    return win32gui.SendMessageTimeout(
        hwnd, msg, wparam, lparam,
        win32con.SMTO_ABORTIFHUNG | win32con.SMTO_BLOCK,
        timeout_ms,
    )


def _children(parent_hwnd: int) -> list[int]:
    import win32gui
    result: list[int] = []
    try:
        win32gui.EnumChildWindows(parent_hwnd, lambda h, _: result.append(h) or True, None)
    except Exception:
        pass
    return result


def enumerate_native_controls(parent_hwnd: int) -> list[dict]:
    _require_windows()
    import win32gui
    out: list[dict] = []
    for hwnd in [parent_hwnd] + _children(parent_hwnd):
        try:
            out.append({
                "hwnd": int(hwnd),
                "control_id": int(win32gui.GetDlgCtrlID(hwnd)),
                "class_name": win32gui.GetClassName(hwnd) or "",
                "text": win32gui.GetWindowText(hwnd) or "",
                "visible": bool(win32gui.IsWindowVisible(hwnd)),
                "enabled": bool(win32gui.IsWindowEnabled(hwnd)),
                "rect": list(win32gui.GetWindowRect(hwnd)),
            })
        except Exception:
            continue
    return out


def _smallest_child_at_point(parent_hwnd: int, screen_x: int, screen_y: int) -> int:
    import win32gui
    candidates: list[tuple[int, int]] = []
    for hwnd in _children(parent_hwnd):
        try:
            if not win32gui.IsWindow(hwnd):
                continue
            left, top, right, bottom = win32gui.GetWindowRect(hwnd)
            if left <= screen_x < right and top <= screen_y < bottom:
                area = max(1, right - left) * max(1, bottom - top)
                candidates.append((area, hwnd))
        except Exception:
            pass
    if candidates:
        candidates.sort(key=lambda item: item[0])
        return candidates[0][1]
    return parent_hwnd


def _read_text(hwnd: int) -> str:
    import win32gui
    try:
        return win32gui.GetWindowText(hwnd) or ""
    except Exception:
        return ""


def _class_name(hwnd: int) -> str:
    import win32gui
    try:
        return win32gui.GetClassName(hwnd) or ""
    except Exception:
        return ""


def _find_edit_candidate(hwnd: int) -> int | None:
    pool = [hwnd] + _children(hwnd)
    for child in pool:
        cls = _class_name(child).lower()
        if "edit" in cls or "richedit" in cls:
            return child
    return None


def _find_camfrog_status_combo(
    parent_hwnd: int,
    current_text: str = "",
    known_statuses: Iterable[str] = (),
) -> int | None:
    """Locate Camfrog's custom-status CComboBoxTS using text + geometry scoring."""
    import win32gui

    known = {str(x).strip().casefold() for x in known_statuses if str(x).strip()}
    candidates: list[tuple[int, int]] = []
    try:
        pl, pt, pr, pb = win32gui.GetWindowRect(parent_hwnd)
        ph = max(1, pb - pt)
        pw = max(1, pr - pl)
    except Exception:
        pl = pt = pr = pb = 0
        ph = pw = 1

    for hwnd in _children(parent_hwnd):
        try:
            cls = _class_name(hwnd).lower()
            if cls != "ccomboboxts" and "combobox" not in cls:
                continue
            text = _read_text(hwnd).strip()
            l, t, r, b = win32gui.GetWindowRect(hwnd)
            width = max(0, r - l)
            height = max(0, b - t)
            rel_y = (t - pt) / ph if ph else 1.0
            rel_x = (l - pl) / pw if pw else 1.0
            score = 0
            if cls == "ccomboboxts":
                score += 100
            if current_text and text.casefold() == current_text.strip().casefold():
                score += 500
            if text and text.casefold() in known:
                score += 400
            # Screenshot/build: custom status spans most of window under profile header.
            if 0.12 <= rel_y <= 0.32:
                score += 120
            if rel_x <= 0.15:
                score += 20
            if width >= int(pw * 0.60):
                score += 100
            elif width >= 160:
                score += 30
            if 18 <= height <= 60:
                score += 20
            candidates.append((score, hwnd))
        except Exception:
            continue

    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0], reverse=True)
    log.info("Camfrog combo candidates: %s", candidates[:5])
    return candidates[0][1]


def _send_key(hwnd: int, vk: int, *, ctrl: bool = False) -> None:
    import win32con
    if ctrl:
        _send_timeout(hwnd, win32con.WM_KEYDOWN, win32con.VK_CONTROL, 0)
    _send_timeout(hwnd, win32con.WM_KEYDOWN, vk, 0)
    _send_timeout(hwnd, win32con.WM_KEYUP, vk, 0)
    if ctrl:
        _send_timeout(hwnd, win32con.WM_KEYUP, win32con.VK_CONTROL, 0)


def _notify_combo_parent(parent_hwnd: int, combo_hwnd: int) -> None:
    """Notify Camfrog's parent exactly like an edited/selected combo would.

    WM_SETTEXT alone mutates visible text but custom wrappers frequently publish
    state only from WM_COMMAND/CBN handlers.  Sending the standard notifications
    is background-safe and does not activate the window.
    """
    import win32con
    import win32gui

    control_id = int(win32gui.GetDlgCtrlID(combo_hwnd))
    if control_id < 0:
        return
    notifications = [
        getattr(win32con, "CBN_EDITUPDATE", 6),
        getattr(win32con, "CBN_EDITCHANGE", 5),
        getattr(win32con, "CBN_SELCHANGE", 1),
        getattr(win32con, "CBN_SELENDOK", 9),
        getattr(win32con, "CBN_CLOSEUP", 8),
    ]
    for code in notifications:
        try:
            _send_timeout(parent_hwnd, win32con.WM_COMMAND, _make_wparam(control_id, code), combo_hwnd, 1000)
        except Exception as exc:
            log.debug("Combo notification %s failed: %s", code, exc)


def _verify_combo_value(combo_hwnd: int, value: str, retries: int = 4) -> tuple[bool, str]:
    expected = value.strip()
    observed = ""
    edit = _find_edit_candidate(combo_hwnd)
    for _ in range(retries):
        for hwnd in ([edit] if edit else []) + [combo_hwnd]:
            if not hwnd:
                continue
            observed = _read_text(hwnd).strip()
            if observed == expected:
                return True, observed
        time.sleep(0.12)
    return False, observed


def _set_native_combo_text(parent_hwnd: int, combo_hwnd: int, value: str) -> BackgroundResult:
    import win32con

    edit = _find_edit_candidate(combo_hwnd)
    target = edit or combo_hwnd

    # Set text without activating Camfrog.
    _send_timeout(target, win32con.WM_SETTEXT, 0, value, timeout_ms=1200)

    # Custom combo code commonly commits from parent WM_COMMAND handlers.
    _notify_combo_parent(parent_hwnd, combo_hwnd)

    # Enter is an additional commit signal to the wrapper/edit.
    _send_key(target, win32con.VK_RETURN)
    _send_key(combo_hwnd, win32con.VK_RETURN)
    _notify_combo_parent(parent_hwnd, combo_hwnd)

    verified, observed = _verify_combo_value(combo_hwnd, value)
    if verified:
        return BackgroundResult(
            True,
            "Camfrog custom-status combo committed in background and verified",
            combo_hwnd,
            True,
            observed,
        )

    # Some wrappers ignore WM_SETTEXT but consume WM_CHAR.
    _send_key(target, ord("A"), ctrl=True)
    _send_key(target, win32con.VK_BACK)
    for ch in value:
        _send_timeout(target, win32con.WM_CHAR, ord(ch), 0)
    _notify_combo_parent(parent_hwnd, combo_hwnd)
    _send_key(target, win32con.VK_RETURN)
    _notify_combo_parent(parent_hwnd, combo_hwnd)

    verified, observed = _verify_combo_value(combo_hwnd, value)
    if verified:
        return BackgroundResult(
            True,
            "Camfrog custom-status combo committed via background character path and verified",
            combo_hwnd,
            True,
            observed,
        )

    return BackgroundResult(
        False,
        "Camfrog status control was reached, but commit could not be verified; no success reported",
        combo_hwnd,
        False,
        observed,
    )


def set_status_background(
    parent_hwnd: int,
    relative_x: float,
    relative_y: float,
    value: str,
    *,
    current_text: str = "",
    known_statuses: Iterable[str] = (),
) -> BackgroundResult:
    """Background-first Camfrog status edit without activating/restoring Camfrog."""
    _require_windows()
    if not value:
        return BackgroundResult(False, "Status cannot be empty")
    if not (0.0 <= relative_x <= 1.0 and 0.0 <= relative_y <= 1.0):
        return BackgroundResult(False, "Relative target coordinates must be between 0.0 and 1.0")

    import win32con
    import win32gui

    if not win32gui.IsWindow(parent_hwnd):
        return BackgroundResult(False, "Camfrog window handle is no longer valid")

    try:
        combo = _find_camfrog_status_combo(
            parent_hwnd,
            current_text=current_text,
            known_statuses=known_statuses,
        )
        if combo:
            result = _set_native_combo_text(parent_hwnd, combo, value)
            if result.ok:
                return result
            # If we confidently found CComboBoxTS but could not commit it, do not
            # return a false success from the coordinate compatibility path.
            if _class_name(combo).lower() == "ccomboboxts":
                return result

        # Compatibility route for older/different builds.
        try:
            placement = win32gui.GetWindowPlacement(parent_hwnd)
            normal_left, normal_top, normal_right, normal_bottom = placement[4]
            width = max(1, normal_right - normal_left)
            height = max(1, normal_bottom - normal_top)
            screen_x = int(normal_left + width * relative_x)
            screen_y = int(normal_top + height * relative_y)
        except Exception:
            left, top, right, bottom = win32gui.GetWindowRect(parent_hwnd)
            width = max(1, right - left)
            height = max(1, bottom - top)
            screen_x = int(left + width * relative_x)
            screen_y = int(top + height * relative_y)

        target_hwnd = _smallest_child_at_point(parent_hwnd, screen_x, screen_y)
        edit_hwnd = _find_edit_candidate(target_hwnd)
        if edit_hwnd:
            _send_timeout(edit_hwnd, win32con.WM_SETTEXT, 0, value, timeout_ms=1200)
            _send_key(edit_hwnd, win32con.VK_RETURN)
            observed = _read_text(edit_hwnd).strip()
            if observed == value.strip():
                return BackgroundResult(True, "Background native Edit updated and verified", edit_hwnd, True, observed)

        # Last background-only compatibility attempt. Do not claim success without verification.
        client_x, client_y = win32gui.ScreenToClient(target_hwnd, (screen_x, screen_y))
        lp = _make_lparam(client_x, client_y)
        _send_timeout(target_hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lp)
        _send_timeout(target_hwnd, win32con.WM_LBUTTONUP, 0, lp)
        _send_key(target_hwnd, ord("A"), ctrl=True)
        _send_key(target_hwnd, win32con.VK_BACK)
        for ch in value:
            _send_timeout(target_hwnd, win32con.WM_CHAR, ord(ch), 0)
        _send_key(target_hwnd, win32con.VK_RETURN)
        observed = _read_text(target_hwnd).strip()
        if observed == value.strip():
            return BackgroundResult(True, "Background compatibility route verified", target_hwnd, True, observed)
        return BackgroundResult(False, "Background compatibility route could not verify the new status", target_hwnd, False, observed)
    except Exception as exc:
        log.exception("Background Win32 automation failed")
        return BackgroundResult(False, f"Background Win32 automation failed: {exc}")
