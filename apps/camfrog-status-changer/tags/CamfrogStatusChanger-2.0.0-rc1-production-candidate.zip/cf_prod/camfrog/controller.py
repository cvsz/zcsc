from __future__ import annotations

import logging
import os
import re
import subprocess
import time
import threading
from dataclasses import dataclass

from .detector import find_processes
from .background_win32 import set_status_background

log = logging.getLogger(__name__)


@dataclass
class ChangeResult:
    ok: bool
    message: str
    previous_value: str = ""
    new_value: str = ""


class CamfrogController:
    def __init__(self, config: dict):
        self.config = config
        self._apply_lock = threading.Lock()
        self._last_apply_monotonic = 0.0

    def ensure_running(self) -> ChangeResult:
        if find_processes():
            return ChangeResult(True, "Camfrog is running")
        exe = self.config["camfrog"].get("executable", "").strip()
        if not exe:
            return ChangeResult(False, "Camfrog executable is not configured")
        try:
            subprocess.Popen([exe], shell=False)
        except Exception as exc:
            return ChangeResult(False, f"Failed to start Camfrog: {exc}")
        for _ in range(30):
            if find_processes():
                return ChangeResult(True, "Camfrog started")
            time.sleep(0.5)
        return ChangeResult(False, "Camfrog did not start within timeout")

    def _desktop(self):
        if os.name != "nt":
            raise RuntimeError("Windows UI Automation is only available on Windows")
        from pywinauto import Desktop
        return Desktop(backend="uia")

    def _find_window_by_pid(self):
        """Locate Camfrog's main top-level HWND from its process id(s).

        This avoids depending on the localized/window title, which can change
        between Camfrog releases.  The returned HWND is wrapped with the UIA
        backend so the rest of the controller can keep using pywinauto.
        """
        if os.name != "nt":
            return None

        import win32gui

        pids = {int(p.pid) for p in find_processes()}
        if not pids:
            return None

        candidates = []

        def enum_cb(hwnd, _):
            try:
                if not win32gui.IsWindow(hwnd):
                    return True
                _tid, pid = win32gui.GetWindowThreadProcessId(hwnd)
                if int(pid) not in pids:
                    return True

                title = win32gui.GetWindowText(hwnd) or ""
                cls = win32gui.GetClassName(hwnd) or ""
                left, top, right, bottom = win32gui.GetWindowRect(hwnd)
                width = max(0, right - left)
                height = max(0, bottom - top)
                area = width * height

                score = 0
                if "camfrog" in title.lower():
                    score += 300
                if "video chat" in title.lower():
                    score += 150
                if win32gui.IsWindowVisible(hwnd):
                    score += 80
                if area >= 200 * 300:
                    score += 60
                if width >= 250 and height >= 400:
                    score += 40
                if title:
                    score += 20

                candidates.append((score, area, hwnd, title, cls))
            except Exception:
                pass
            return True

        win32gui.EnumWindows(enum_cb, None)
        if not candidates:
            return None

        candidates.sort(key=lambda item: (item[0], item[1]), reverse=True)
        hwnd = int(candidates[0][2])
        log.info(
            "Camfrog window selected by PID: hwnd=%s title=%r class=%r score=%s",
            hwnd, candidates[0][3], candidates[0][4], candidates[0][0],
        )
        return self._desktop().window(handle=hwnd)

    def find_window(self):
        # Prefer PID-based discovery. It survives title/localization changes and
        # also finds minimized windows because EnumWindows does not require them
        # to be foreground/visible.
        try:
            win = self._find_window_by_pid()
            if win is not None:
                return win
        except Exception as exc:
            log.warning("PID-based Camfrog window discovery failed: %s", exc)

        # Compatibility fallback for older installations.
        title_re = self.config["camfrog"].get("window_title_regex") or ".*Camfrog Video Chat.*"
        desktop = self._desktop()
        wins = desktop.windows(title_re=title_re, visible_only=False)
        if not wins:
            raise RuntimeError(
                "Camfrog process is running, but its main window was not found. "
                "Use Detect after Camfrog has finished opening, or restart Camfrog and retry."
            )
        return wins[0]

    def inspect_controls(self) -> list[dict]:
        win = self.find_window()
        out = []
        for ctrl in win.descendants():
            try:
                info = ctrl.element_info
                out.append({
                    "title": ctrl.window_text(),
                    "control_type": info.control_type,
                    "automation_id": info.automation_id,
                    "class_name": info.class_name,
                })
            except Exception:
                continue
        return out

    def _find_target(self, win):
        target = self.config.get("target", {})
        automation_id = target.get("automation_id", "").strip()
        control_type = target.get("control_type", "ComboBox").strip() or "ComboBox"
        title_re = target.get("title_regex", ".*") or ".*"

        candidates = []
        for ctrl in win.descendants(control_type=control_type):
            try:
                info = ctrl.element_info
                title = ctrl.window_text() or ""
                if automation_id and info.automation_id != automation_id:
                    continue
                if title_re and not re.match(title_re, title):
                    continue
                candidates.append(ctrl)
            except Exception:
                continue
        if not candidates:
            raise RuntimeError("Configured status control was not found")
        return candidates[0]

    @staticmethod
    def _read_value(ctrl) -> str:
        for getter in (
            lambda: ctrl.get_value(),
            lambda: ctrl.window_text(),
        ):
            try:
                value = getter()
                if value is not None:
                    return str(value)
            except Exception:
                pass
        return ""

    def _coordinate_fallback(self, win, value: str) -> None:
        target = self.config.get("target", {})
        rx = float(target.get("fallback_relative_x", 0.50))
        ry = float(target.get("fallback_relative_y", 0.19))
        if not (0.0 <= rx <= 1.0 and 0.0 <= ry <= 1.0):
            raise RuntimeError("Fallback relative coordinates must be between 0.0 and 1.0")

        try:
            win.restore()
        except Exception:
            pass
        try:
            win.set_focus()
        except Exception:
            pass
        time.sleep(0.25)

        rect = win.rectangle()
        x = int(rect.left + rect.width() * rx)
        y = int(rect.top + rect.height() * ry)

        from pywinauto import mouse
        from pywinauto.keyboard import send_keys
        import pyperclip

        old_clipboard = None
        try:
            old_clipboard = pyperclip.paste()
        except Exception:
            pass

        mouse.click(button="left", coords=(x, y))
        time.sleep(0.15)
        send_keys("^a{BACKSPACE}")
        pyperclip.copy(value)
        send_keys("^v")
        send_keys("{ENTER}")

        if old_clipboard is not None:
            try:
                time.sleep(0.1)
                pyperclip.copy(old_clipboard)
            except Exception:
                pass

    def set_status(self, value: str) -> ChangeResult:
        value = value.replace("\x00", "").strip()
        if not value:
            return ChangeResult(False, "Status cannot be empty")
        max_len = int(self.config.get("advanced", {}).get("max_status_length", 160))
        if len(value) > max_len:
            return ChangeResult(False, f"Status exceeds configured maximum length ({max_len})")

        if not self._apply_lock.acquire(blocking=False):
            return ChangeResult(False, "Another status change is already in progress")
        try:
            minimum = max(1, int(self.config.get("advanced", {}).get("minimum_interval_seconds", 5)))
            now = time.monotonic()
            elapsed = now - self._last_apply_monotonic
            if self._last_apply_monotonic and elapsed < minimum:
                remaining = max(1, int(minimum - elapsed + 0.999))
                return ChangeResult(False, f"Rate limited: retry in {remaining}s")

            running = self.ensure_running()
            if not running.ok:
                return running

            try:
                win = self.find_window()
                previous = ""
                errors: list[str] = []

                try:
                    ctrl = self._find_target(win)
                    previous = self._read_value(ctrl)
                    for action in (
                        lambda: ctrl.set_edit_text(value),
                        lambda: ctrl.iface_value.SetValue(value),
                    ):
                        try:
                            action()
                            time.sleep(0.15)
                            observed = self._read_value(ctrl).strip()
                            if observed == value:
                                errors.append("UIA text changed; continuing to native commit verification")
                                break
                            errors.append(f"UIA wrote control but verification read {observed!r}")
                        except Exception as exc:
                            errors.append(f"UIA: {exc}")

                    try:
                        edit = ctrl.child_window(control_type="Edit").wrapper_object()
                        edit.set_edit_text(value)
                        time.sleep(0.15)
                        observed = self._read_value(edit).strip()
                        if observed == value:
                            errors.append("UIA child Edit text verified; continuing to native commit")
                        else:
                            errors.append(f"UIA child Edit verification read {observed!r}")
                    except Exception as exc:
                        errors.append(f"UIA child Edit: {exc}")
                except Exception as exc:
                    errors.append(f"UIA target: {exc}")

                if self.config.get("target", {}).get("background_enabled", True):
                    try:
                        hwnd = int(win.handle)
                        target = self.config.get("target", {})
                        result = set_status_background(
                            hwnd,
                            float(target.get("fallback_relative_x", 0.50)),
                            float(target.get("fallback_relative_y", 0.19)),
                            value,
                            current_text=previous,
                            known_statuses=self.config.get("status", {}).get("presets", []),
                        )
                        if result.ok and result.verified:
                            self._last_apply_monotonic = time.monotonic()
                            return ChangeResult(True, result.message, previous, value)
                        errors.append(result.message)
                    except Exception as exc:
                        errors.append(f"Win32 background: {exc}")

                advanced = self.config.get("advanced", {})
                if advanced.get("fallback_enabled", False) and not advanced.get("background_only", True):
                    try:
                        self._coordinate_fallback(win, value)
                        self._last_apply_monotonic = time.monotonic()
                        return ChangeResult(True, "Status changed using foreground fallback (not background-verified)", previous, value)
                    except Exception as exc:
                        errors.append(f"Foreground fallback: {exc}")

                detail = "; ".join(errors[-5:]) or "No compatible background strategy succeeded"
                return ChangeResult(False, f"Status change failed. {detail}", previous_value=previous)
            except Exception as exc:
                log.exception("Status change failed")
                return ChangeResult(False, str(exc))
        finally:
            self._apply_lock.release()
