from __future__ import annotations

import os
from pathlib import Path
import psutil

KNOWN_PATHS = [
    Path(r"C:\Program Files\Camfrog\Camfrog Video Chat\Camfrog.exe"),
    Path(r"C:\Program Files (x86)\Camfrog\Camfrog Video Chat\Camfrog.exe"),
]


def find_processes() -> list[psutil.Process]:
    found = []
    for p in psutil.process_iter(["pid", "name", "exe"]):
        try:
            name = (p.info.get("name") or "").lower()
            if "camfrog" in name:
                found.append(p)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return found


def discover_executable() -> str:
    for p in find_processes():
        try:
            exe = p.exe()
            if exe:
                return exe
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    for path in KNOWN_PATHS:
        if path.exists():
            return str(path)
    return ""
