APP_NAME = "Camfrog Status Changer"
APP_ID = "CamfrogStatusChanger"
VERSION = "2.0.0-rc1"
