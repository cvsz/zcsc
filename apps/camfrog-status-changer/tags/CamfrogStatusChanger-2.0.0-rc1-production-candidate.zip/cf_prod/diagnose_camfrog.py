from __future__ import annotations

import json
from pathlib import Path

from system.config_store import ConfigStore
from camfrog.controller import CamfrogController
from camfrog.background_win32 import enumerate_native_controls


def safe_text(item: dict) -> str:
    cls = str(item.get("class_name", "")).lower()
    text = str(item.get("text", ""))
    if "combo" in cls or "button" in cls:
        return text[:120]
    return ""


def main() -> None:
    store = ConfigStore()
    config = store.load()
    ctrl = CamfrogController(config)
    win = ctrl.find_window()
    rows = enumerate_native_controls(int(win.handle))
    safe = []
    for row in rows:
        safe.append({
            "hwnd": row.get("hwnd"),
            "control_id": row.get("control_id"),
            "class_name": row.get("class_name"),
            "text": safe_text(row),
            "visible": row.get("visible"),
            "enabled": row.get("enabled"),
            "rect": row.get("rect"),
        })
    out = store.dir / "camfrog-native-controls-safe.json"
    out.write_text(json.dumps(safe, indent=2, ensure_ascii=False), encoding="utf-8")
    print(out)


if __name__ == "__main__":
    main()
