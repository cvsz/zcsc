# Camfrog Status Changer 2.0.0-rc1

Windows desktop utility for user-controlled Camfrog custom-status presets and rotation. The default automation mode is background-only and does not intentionally restore/focus Camfrog or move the physical mouse.

## Features

- Manual custom-status apply
- Sequential/random rotation
- Seconds/minutes/hours interval selection
- System tray operation and Windows startup
- PID-based Camfrog window detection
- Native `CComboBoxTS` targeting plus UI Automation compatibility
- Read-only Camfrog registry preset discovery with sanitization
- Config corruption recovery and atomic saves
- Single-instance guard
- Apply concurrency/rate-limit guardrails
- Rotating logs
- Safe native-control diagnostics
- Hidden-console Windows EXE build
- Release SHA-256 manifest

## Development test

```cmd
run_dev.bat
```

## Self-test

```cmd
py self_test.py
```

## Safe diagnostic

With Camfrog running:

```cmd
py diagnose_camfrog.py
```

Output is stored under `%APPDATA%\CamfrogStatusChanger`.

## Production-candidate build

```cmd
build_exe_fixed.bat
```

Artifacts:

```text
dist\CamfrogStatusChanger.exe
dist\release-manifest.json
```

The build fails if regression tests or compile checks fail.

## Runtime data

```text
%APPDATA%\CamfrogStatusChanger\config.json
%APPDATA%\CamfrogStatusChanger\logs\app.log
%APPDATA%\CamfrogStatusChanger\self-test.json
%APPDATA%\CamfrogStatusChanger\camfrog-native-controls-safe.json
```

## Security model

- Does not store Camfrog passwords.
- Registry status discovery is read-only.
- Sensitive registry key/value names are excluded from status parsing.
- Background-only is enabled by default.
- Foreground fallback is explicitly opt-in.
- Do not add antivirus exclusions simply to suppress an alert; investigate/sign/scan the final artifact instead.

See `PRODUCTION-READINESS.md` for release gates that still require a real Windows + Camfrog E2E run.
