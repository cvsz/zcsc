$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$exe = Join-Path $PSScriptRoot 'dist\CamfrogStatusChanger.exe'
if (-not (Test-Path $exe)) { throw "Missing $exe" }
$hash = (Get-FileHash -Algorithm SHA256 $exe).Hash.ToLowerInvariant()
$size = (Get-Item $exe).Length
$manifest = [ordered]@{
  artifact = 'CamfrogStatusChanger.exe'
  sha256 = $hash
  size_bytes = $size
  built_utc = (Get-Date).ToUniversalTime().ToString('o')
  platform = 'windows-x64'
}
$manifest | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $PSScriptRoot 'dist\release-manifest.json')
Write-Host "SHA256: $hash"
