from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

DEFAULT_CONFIG = {
    "camfrog": {
        "executable": "",
        "window_title_regex": ".*Camfrog Video Chat.*",
        "auto_start": False,
        "restore_window_state": True,
    },
    "target": {
        "control_type": "ComboBox",
        "automation_id": "",
        "title_regex": ".*",
        "fallback_relative_x": 0.50,
        "fallback_relative_y": 0.19,
        "background_enabled": True,
    },
    "status": {
        "presets": ["Sea THAIFIGHT", "ZEAZDEV COMPANY LIMITED", "Busy", "Available"],
        "rotation": {"enabled": False, "interval_seconds": 600, "mode": "sequential"},
    },
    "startup": {"windows_startup": False, "start_minimized": False, "system_tray": True},
    "registry": {"import_presets_on_start": True},
    "advanced": {"minimum_interval_seconds": 5, "fallback_enabled": False, "background_only": True},
}


class ConfigStore:
    def __init__(self) -> None:
        appdata = os.getenv("APPDATA")
        base = Path(appdata) if appdata else (Path.home() / ".config")
        self.dir = base / "CamfrogStatusChanger"
        self.path = self.dir / "config.json"

    def ensure_defaults(self) -> None:
        self.dir.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.save(DEFAULT_CONFIG)

    def load(self) -> dict[str, Any]:
        self.ensure_defaults()
        with self.path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return self._merge(DEFAULT_CONFIG, data)

    def save(self, data: dict[str, Any]) -> None:
        self.dir.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        tmp.replace(self.path)

    @staticmethod
    def _merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        out = json.loads(json.dumps(base))
        for k, v in override.items():
            if isinstance(v, dict) and isinstance(out.get(k), dict):
                out[k] = ConfigStore._merge(out[k], v)
            else:
                out[k] = v
        return out
