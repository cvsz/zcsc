# Camfrog Status Changer v1.2 Background Test

v1 (Test Build)

Windows desktop utility for changing the custom Camfrog status field through Windows UI Automation.

## Features

- User-configurable Camfrog executable path
- Auto-detect running Camfrog/process path
- User-configurable UI Automation selector
- Manual custom status change
- Sequential/random status rotation
- Auto-start Camfrog when needed
- Restore minimized state when possible
- Windows startup option
- UI control inspector (`uia-controls.json`)
- Persistent config under `%APPDATA%\CamfrogStatusChanger\config.json`
- File logging under `%APPDATA%\CamfrogStatusChanger\logs\app.log`

## Important test note

Camfrog versions may expose the custom status field differently. This build intentionally includes **Inspect** so you can discover the actual `ControlType`, `AutomationId`, and visible title exposed by your installed Camfrog version.

## Fast test on Windows

1. Extract this project.
2. Double-click `run_dev.bat`.
3. Log into Camfrog normally.
4. Click **Detect**.
5. Click **Inspect**.
6. Open `%APPDATA%\CamfrogStatusChanger\uia-controls.json`.
7. Find the control corresponding to your current custom status (for example `Sea THAIFIGHT`).
8. Enter its `Control type`, `Automation ID` if present, and a suitable `Title regex` in the GUI.
9. Enter a new status and click **Apply now**.

Example selector if the field is a normal ComboBox:

- Control type: `ComboBox`
- Automation ID: leave blank initially
- Title regex: `.*Sea THAIFIGHT.*` (or `.*` if unique)

If Camfrog exposes the value as an Edit control instead, change `Control type` to `Edit`.

## Build EXE locally

Double-click:

```text
build_exe.bat
```

Output:

```text
dist\CamfrogStatusChanger.exe
```

Python is required only on the build machine, not on PCs running the generated EXE.

## GitHub Actions

The included workflow `.github/workflows/build-windows.yml` creates the Windows x64 EXE on a native Windows runner and publishes it as a workflow artifact.

## Security

- Does not request or store a Camfrog password.
- Does not bypass Camfrog authentication.
- Uses the user's existing logged-in Camfrog client session.
- Do not disable antivirus globally to run a build. Prefer clean builds, hashes and code signing for distribution.

## Current limitations

- Actual Camfrog UI selector must be validated against the installed Camfrog version.
- Some custom-rendered controls may not expose a stable UIA ValuePattern. The included fallback can require restoring/focusing the window.
- System tray UI is planned but not enabled in this first test build; closing the app exits it.

## v1.1 background automation

The controller now uses a background-first strategy:

1. UI Automation ValuePattern/Edit APIs when Camfrog exposes a writable control.
2. Win32 `WM_*` messages sent directly to the calibrated Camfrog target without restoring or focusing the window.
3. Foreground mouse/keyboard fallback is **disabled by default** and can be enabled explicitly in the GUI.

Close the GUI with the X button to hide it to the system tray. Status rotation continues in the background. Use the tray menu **Exit** to terminate the application.

For custom-rendered Camfrog builds, first open Camfrog, press **Capture target (3s)** and place the mouse over the custom status field. This calibration is stored as coordinates relative to the Camfrog window; subsequent scheduled changes do not move the physical mouse or bring Camfrog to the foreground.


## v1.2 fixes
- Non-blocking 3-second target capture; pywinauto discovery runs on a worker thread.
- Bounded SendMessageTimeout for cross-process background messages.
- Native Edit/RichEdit WM_SETTEXT path before custom-rendered coordinate messaging.
- Background-only remains the default; no foreground restore/focus unless explicitly enabled.

## Camfrog 2026 native integration notes (v1.3)

Static analysis of the supplied 64-bit Camfrog executable identified internal UI/resource names:

- `custom_status_combo`
- `custom_status_text`
- `change_status_button`
- `status_menu`
- custom combo wrapper class `CComboBoxTS`
- registry/history area `Software\\Camfrog\\Client` and `\\Custom status list`

The background controller therefore prefers a native `CComboBoxTS` HWND in the profile/status region before falling back to calibrated coordinates. This route does not restore Camfrog, move the mouse, or use SendInput/clipboard.

The registry `Custom status list` appears to represent saved/history items and is not treated as proof of the currently published presence/status.

## v1.5 rotation timing
- Rotation waits one full interval before the first automatic status change.
- Interval UI uses minutes or hours instead of raw seconds.
- Default interval for a fresh configuration is 10 minutes.
- Minimum automatic rotation interval is 1 minute.

## v1.6 — Camfrog Registry preset import

The app can now read Camfrog's saved custom-status list from the Windows Registry and merge it into the GUI preset list.

- Read-only: the app does **not** modify Camfrog registry values.
- Scans `HKCU\\Software\\Camfrog\\Client` and `CurrentVersion\\ProfileInfo` in both 32-bit and 64-bit registry views.
- Looks only for custom-status-related keys/values such as `Custom status list` and ignores unrelated account/session data.
- `Read Camfrog Registry` imports on demand.
- `Import Camfrog custom-status list on startup` can refresh presets automatically.
- Duplicate statuses are removed case-insensitively while preserving existing preset order.

## v1.7 — Hidden Console + Active sec/min/hr

- Packaged EXE is built with `--windowed --noconsole`, so normal use has no CMD window.
- Windows startup now uses `HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run` instead of a Startup `.cmd` file, preventing command-window flashes.
- Development users can run `run_hidden.vbs` after dependencies are installed.
- Rotation interval supports `seconds`, `minutes`, and `hours`.
- Unit conversion is validated centrally and persisted immediately when the unit is changed.
- Minimum interval is 5 seconds (intended for testing); use minutes/hours for normal operation.

### Hidden development launch

First-time dependency install:

```bat
run_dev.bat
```

After dependencies are installed, launch without a console:

```text
Double-click run_hidden.vbs
```

### Examples

- `30 seconds` -> 30 seconds
- `5 minutes` -> 300 seconds
- `2 hours` -> 7200 seconds

Changing the unit updates the effective interval used when `Start rotation` is pressed. The status line reports the effective interval.
