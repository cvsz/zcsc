# Camfrog Video Chat — Custom Status Deep Reverse Engineering

## Scope
Target binary: `Camfrog Video Chat.exe`
SHA-256: `0b744602c004536dcf81e9965e8cb17358eb276b3876a1e70c50f72777c27e06`
Format: PE32+ x86-64
Image base: `0x140000000`

This analysis is scoped to the custom-status feature and avoids credential/session extraction.

## Confirmed static anchors
UI/resource strings:
- `custom_status_combo`
- `custom_status_text`
- `change_status_button`
- `status_menu`
- `status_button`
- `CComboBoxTS`
- `CEdit4ComboInnerTS`
- `CButtonStatusTS`

Internal RTTI names:
- `Messages::ChangeStatus`
- `Messages::CSNet_Status`
- `Messages::CSNet_SetSelfStatus`
- `Messages::CSNet_ChangeStatusEx`
- `Messages::CSToNet_SetSelfStatus`
- `Messages::CSToNet_GetStatus`

Protocol/schema strings:
- `proto.client.user.CSPacket020401.text_status`
- `proto.client.user.CSPacket020402.custom_status`
- `proto.client.user.ClientProfile.User.custom_status`
- `exStatusUpdate`

Registry/config anchors:
- `Software\\Camfrog\\Client`
- `Software\\Camfrog\\Client\\CurrentVersion\\ProfileInfo\\`
- `\\Custom status list`

## UI string xrefs
`custom_status_combo` UTF-16 xrefs found in `.text`:
- `0x1403212A3` (function `0x14031DB00–0x1403214AE`)
- `0x14059C1FC` (function `0x14059BC70–0x14059C6C4`)
- `0x14075B9C9` (function `0x14075B980–0x14075BA40`)

`change_status_button` UTF-16 xrefs:
- `0x140748B9F` (function `0x1407476E0–0x140748FF2`)
- `0x140750C6C` (function `0x140750BF0–0x140750D07`)
- `0x140755591` (function `0x140755180–0x140755715`)
- `0x14075EF56` (function `0x14075EF00–0x14075FBB1`)

These functions appear to bind/find UI controls. They are useful for discovering control ownership, but the string xrefs alone do not prove which one is the click/commit handler.

## MSVC RTTI → vtable → constructor map
The MSVC RTTI Complete Object Locator structures were resolved from TypeDescriptor RVAs, then vtables were located via COL pointers.

### `Messages::ChangeStatus`
- TypeDescriptor RVA: `0x305FE70`
- COL RVA: `0x2C54D40`
- vtable VA: `0x1425F6D70`
- code ref assigning vtable: `0x140273D93`

At `0x140273D93`, the code loads `0x1425F6D70` and stores it into a stack-allocated object before dispatching it through an indirect call. This is a strong candidate for a `Messages::ChangeStatus` object construction/dispatch path.

### `Messages::CSToNet_SetSelfStatus`
- TypeDescriptor RVA: `0x3074E20`
- COL RVA: `0x2C7BA38`
- vtable VA: `0x1426604D8`
- constructor-style refs: `0x140782AF1`, `0x141E8818C`

The constructor-like function around `0x140782AB0` writes:
- base/type field at `+0x08` = `0x96`
- another field at `+0x10` = `0x0A`
- vtable = `0x1426604D8`
- copies a status/string-like object into `+0x20`
- writes byte flags at offsets `+0x40`, `+0x41`, `+0x42`

This is currently the strongest static candidate for constructing the client-to-network self-status message.

### `Messages::CSNet_SetSelfStatus`
- TypeDescriptor RVA: `0x306C828`
- COL RVA: `0x2C698F8`
- vtable VA: `0x1426340E0`
- constructor refs: `0x1405287C4`, `0x140782C7C`

A constructor-like path around `0x140782C30` assigns the vtable and copies a string-like object into the message.

### `Messages::CSNet_ChangeStatusEx`
- TypeDescriptor RVA: `0x306CD20`
- COL RVA: `0x2C6A4B0`
- vtable VA: `0x142634240`
- constructor refs: `0x140527DB4`, `0x14078BE72`

The path around `0x14078BE30` writes:
- message/type field at `+0x08` = `0x95`
- field at `+0x10` = `0x13`
- vtable = `0x142634240`

This is a strong candidate for an extended status update structure.

## Protobuf serialization anchors
### `CSPacket020401.text_status`
String VA: `0x142B5CFC0`
Direct RIP-relative xref: `0x141E61C4D`
Containing function: `0x141E61C40–0x141E61CC5`

Observed behavior:
- loads the schema/field-name pointer
- tests string length
- emits protobuf wire byte `0x12`
- copies the string bytes into the outgoing buffer

This is strong evidence that this function serializes a text-status string into a protobuf packet.

### `CSPacket020402.custom_status`
String VA: `0x142B5ECB8`
Direct RIP-relative xref: `0x141E81580`
Containing function: `0x141E813B0–0x141E81DF1`

The function accesses a string-like member and feeds it to the same protobuf helper used by other generated message serializers.

## Working hypothesis (not yet dynamically proven)
The evidence supports the following likely architecture:

`custom_status_combo` / `change_status_button`
→ `Messages::ChangeStatus`
→ `Messages::CSToNet_SetSelfStatus` and/or `CSNet_ChangeStatusEx`
→ protobuf object carrying `text_status` / `custom_status`
→ transport layer

The exact UI-handler-to-message-constructor edge is not statically proven yet. Dynamic tracing should confirm it before any in-process integration is attempted.

## Why the existing Status Changer does not reliably publish
`WM_SETTEXT` or UIA can mutate the visible `CComboBoxTS` text, but that does not guarantee the internal `Messages::ChangeStatus` dispatch path executes. The server-visible status therefore may remain unchanged even when the local control text changes.

## High-value dynamic breakpoints (module-relative)
Assuming module image base `Camfrog Video Chat.exe + RVA`:

- `ChangeStatus` vtable assignment: RVA `0x0273D93`
- `CSToNet_SetSelfStatus` constructor body: RVA `0x0782AB0`
- `CSToNet_SetSelfStatus` vtable assignment: RVA `0x0782AF1`
- `CSNet_SetSelfStatus` constructor area: RVA `0x0782C30`
- `CSNet_SetSelfStatus` vtable assignment: RVA `0x0782C7C`
- `CSNet_ChangeStatusEx` constructor path: RVA `0x0527D70`
- `CSNet_ChangeStatusEx` vtable assignment: RVA `0x0527DB4`
- alternate `CSNet_ChangeStatusEx` path: RVA `0x078BE30`
- protobuf `text_status` serializer: RVA `0x1E61C40`
- protobuf `custom_status` serializer: RVA `0x1E813B0`

Use RVAs, not absolute addresses, because ASLR changes the module base at runtime.

## Dynamic experiment
Use one unmistakable test value, e.g. `CF_RE_TEST_8F31`.

A. Open status editor and cancel.
B. Enter `CF_RE_TEST_8F31` and commit through Camfrog's own UI.

Record which breakpoints fire only in B. At each hit record:
- call stack
- caller RVA
- RCX/RDX/R8/R9
- relevant object memory (status string only)
- thread ID

Do not collect unrelated account credentials, authentication buffers, cookies, or tokens.

## Release gate for direct integration
Do not call internal functions from the Status Changer until all are known:
1. exact handler/dispatcher RVA for this binary hash
2. ABI and object ownership/lifetime
3. thread-affinity requirement
4. correct message constructor and destructor
5. successful server-visible test
6. fail-closed signature/hash check for future Camfrog versions

Directly calling guessed internal addresses without these controls can crash or corrupt Camfrog state.
