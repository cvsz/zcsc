# Camfrog Custom Status RE v2

This kit contains the verified static map produced from the uploaded Camfrog Video Chat executable.

Files:
- `CAMFROG-STATUS-DEEP-RE.md` — detailed findings and evidence status
- `static-map.json` — machine-readable RVA/vtable/protobuf map
- `x64dbg-status-trace-plan.txt` — dynamic trace procedure

Important: absolute VAs in the report are for static analysis. Use module-relative RVAs for runtime debugging because ASLR is enabled.
