from __future__ import annotations
import random
from dataclasses import dataclass

DEFAULT_PALETTE = ["#FF3B30","#FF9500","#FFCC00","#34C759","#00C7BE","#0A84FF","#5E5CE6","#BF5AF2","#FF2D55"]

@dataclass
class StyleState:
    marquee_offset: int = 0

def random_color(palette: list[str] | None = None) -> str:
    values = [x.strip() for x in (palette or DEFAULT_PALETTE) if str(x).strip()]
    return random.choice(values or DEFAULT_PALETTE)

def marquee_frame(text: str, offset: int, width: int = 28) -> tuple[str, int]:
    """Return one deterministic marquee frame and next offset.
    Newlines are preserved by animating each non-empty line independently.
    """
    width = max(4, int(width))
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out = []
    for line in lines:
        if not line:
            out.append("")
            continue
        padded = (" " * width) + line + (" " * width)
        cycle = len(line) + width
        pos = offset % max(1, cycle)
        window = (padded + padded)[pos:pos+width]
        out.append(window.rstrip())
    return "\r\n".join(out), offset + 1

def apply_styles(
    text: str,
    *,
    random_color_enabled: bool = False,
    marquee_enabled: bool = False,
    marquee_offset: int = 0,
    marquee_width: int = 28,
    color_template: str = "[color={color}]{text}[/color]",
    palette: list[str] | None = None,
) -> tuple[str, int, str | None]:
    value = text
    next_offset = marquee_offset
    if marquee_enabled:
        value, next_offset = marquee_frame(value, marquee_offset, marquee_width)
    chosen = None
    if random_color_enabled:
        chosen = random_color(palette)
        # User-configurable template; malformed templates fail closed to plain text.
        try:
            value = color_template.format(color=chosen, text=value)
        except Exception:
            pass
    return value, next_offset, chosen
