# Camfrog Status Changer 2.2.0-rc2 — Merged Candidate

# Camfrog Status Changer 2.0.0-rc2

RC2 fixes UIA ComboBox/Edit dispatch and native CComboBoxTS owner-chain commit notifications.

# Camfrog Status Changer 2.0.0-rc1

Windows desktop utility for user-controlled Camfrog custom-status presets and rotation. The default automation mode is background-only and does not intentionally restore/focus Camfrog or move the physical mouse.

## Features

- Manual custom-status apply
- Sequential/random rotation
- Seconds/minutes/hours interval selection
- System tray operation and Windows startup
- PID-based Camfrog window detection
- Native `CComboBoxTS` targeting plus UI Automation compatibility
- Read-only Camfrog registry preset discovery with sanitization
- Config corruption recovery and atomic saves
- Single-instance guard
- Apply concurrency/rate-limit guardrails
- Rotating logs
- Safe native-control diagnostics
- Hidden-console Windows EXE build
- Release SHA-256 manifest

## Development test

```cmd
run_dev.bat
```

## Self-test

```cmd
py self_test.py
```

## Safe diagnostic

With Camfrog running:

```cmd
py diagnose_camfrog.py
```

Output is stored under `%APPDATA%\CamfrogStatusChanger`.

## Production-candidate build

```cmd
build_exe_fixed.bat
```

Artifacts:

```text
dist\CamfrogStatusChanger.exe
dist\release-manifest.json
```

The build fails if regression tests or compile checks fail.

## Runtime data

```text
%APPDATA%\CamfrogStatusChanger\config.json
%APPDATA%\CamfrogStatusChanger\logs\app.log
%APPDATA%\CamfrogStatusChanger\self-test.json
%APPDATA%\CamfrogStatusChanger\camfrog-native-controls-safe.json
```

## Security model

- Does not store Camfrog passwords.
- Registry status discovery is read-only.
- Sensitive registry key/value names are excluded from status parsing.
- Background-only is enabled by default.
- Foreground fallback is explicitly opt-in.
- Do not add antivirus exclusions simply to suppress an alert; investigate/sign/scan the final artifact instead.

See `PRODUCTION-READINESS.md` for release gates that still require a real Windows + Camfrog E2E run.

## 2.1.0-rc1 native profile update

This build includes a version-gated static-analysis profile for the exact Camfrog x64 binary supplied during testing (SHA-256 `0b744602c004536dcf81e9965e8cb17358eb276b3876a1e70c50f72777c27e06`). The profile improves native class targeting for `CComboBoxTS`, `CEdit4ComboInnerTS`, and `CButtonStatusTS` and adds safe diagnostics for the discovered status-related RVAs.

The application **does not call the discovered internal RVAs directly**. Those addresses remain diagnostic-only until their runtime ABI/call chain is verified, avoiding crashes and state corruption when Camfrog changes. Run `py diagnose_camfrog.py` to create `%APPDATA%\\CamfrogStatusChanger\\camfrog-native-diagnostic-safe.json` with the binary fingerprint, profile match, class matches, and sanitized control inventory.

## 2.1.1-rc2 safety fix

- Generic Camfrog `CButtonTS` controls are never clicked by background automation.
- Only the positively identified `CButtonStatusTS` class may receive `BM_CLICK`.
- Added edit-change notifications (`EN_UPDATE`, `EN_CHANGE`) before combo commit.
- Registry preset import now treats only `status`/`custom` paths or value names as status sources; generic `ProfileInfo` values such as nicknames are excluded.
- `Background only` and `Allow foreground fallback` are mutually exclusive in the GUI/config path.
- Runtime status operations contain no browser/URL launch path.


## 2.1.3-rc4 real history reader

- `Read Camfrog History` now fills a separate read-only History panel instead of silently contaminating Presets.
- `Import all → Presets` is explicit and user-controlled.
- REG_BINARY history values are carved as aligned UTF-16LE and printable ASCII, including blobs with metadata prefixes.
- Only explicit `status` / `custom` registry sources are parsed; nicknames/profile metadata remain excluded.
- Run `py registry_history_dump.py` to write `%APPDATA%\CamfrogStatusChanger\camfrog-history-sources-safe.json` containing decoded status text and the exact registry source path/value name.

## 2.1.4-rc5 — Four-line status editor

The Set status panel now exposes four explicit fields:

- Line 1 / text1
- Line 2 / text2
- Line 3 / text3
- Line 4 / text4

`Apply 2 lines` composes them as `text1\ntext2\ntext3\ntext4`, preserves intentional blank lines in the middle, and removes only trailing blank lines. The editor values persist in `status.editor_lines`.


## 2-line status editor
The status editor intentionally uses `text1` and `text2` only. The payload is composed with Windows CRLF (`text1\r\ntext2`) and verification normalizes CRLF/LF differences. This matches the observed Camfrog behavior better than the previous 4-line experiment.


## Merged RC2 additions

- Bundled `app.ico` generated from the supplied transparent Z logo.
- Both Windows build scripts use `app.ico` automatically when present.
- Style controls: **Random Color** and **Marquee** as opt-in checkboxes.
- UI language selector: **EN / TH**.
- Rotation remains **1 preset per interval**.
- Status editor remains **2 lines** (`text1`, `text2`) based on the latest tested behavior.
- History reader, native profile, safe-commit guardrails, hidden-console build and production build gates remain included.

> Random Color uses a configurable text-format template. Whether Camfrog renders the markup as color is a runtime/server capability and must be verified in the target Camfrog build. Marquee is implemented as one generated frame per scheduler interval.
