from __future__ import annotations

import json
import logging
import os
import threading
import tkinter as tk
from typing import Optional
from tkinter import filedialog, messagebox

import customtkinter as ctk

from automation.rotation import RotationWorker
from automation.intervals import interval_to_seconds, seconds_to_interval, format_interval
from camfrog.controller import CamfrogController
from camfrog.detector import discover_executable
from camfrog.registry_status import merge_presets, read_camfrog_custom_statuses
from system.startup import set_start_with_windows
from status_text import compose_two_lines
from status_styles import apply_styles

log = logging.getLogger(__name__)

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("green")


class AppUI(ctk.CTk):
    def __init__(self, store):
        super().__init__()
        self.store = store
        self.config_data = store.load()
        self.controller = CamfrogController(self.config_data)
        self.rotation = RotationWorker(self._apply_status_background)
        self._tray_icon = None
        self._tray_thread: Optional[threading.Thread] = None
        self._exiting = False
        self._marquee_offset = 0

        self.title("Camfrog Status Changer")
        self.geometry("760x590")
        self.minsize(720, 560)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self._build()
        self._load_config_to_ui()
        self.after(300, self._auto_detect_if_needed)
        self.after(500, self._start_tray)
        self.after(650, self._auto_import_registry_presets)
        self.after(800, self._resume_background_automation)

    def _build(self):
        root = ctk.CTkScrollableFrame(self)
        root.pack(fill="both", expand=True, padx=14, pady=14)

        ctk.CTkLabel(root, text="Camfrog Status Changer", font=ctk.CTkFont(size=24, weight="bold")).pack(anchor="w", pady=(0, 12))

        self.state_label = ctk.CTkLabel(root, text="Ready")
        self.state_label.pack(anchor="w", pady=(0, 10))

        exe_frame = ctk.CTkFrame(root)
        exe_frame.pack(fill="x", pady=6)
        ctk.CTkLabel(exe_frame, text="Camfrog executable").grid(row=0, column=0, sticky="w", padx=10, pady=(10, 4))
        self.exe_var = tk.StringVar()
        ctk.CTkEntry(exe_frame, textvariable=self.exe_var).grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 10))
        ctk.CTkButton(exe_frame, text="Browse", width=90, command=self._browse).grid(row=1, column=1, padx=(0, 10), pady=(0, 10))
        ctk.CTkButton(exe_frame, text="Detect", width=90, command=self._detect).grid(row=1, column=2, padx=(0, 6), pady=(0, 10))
        ctk.CTkButton(exe_frame, text="Native profile", width=110, command=self._show_native_profile).grid(row=1, column=3, padx=(0, 10), pady=(0, 10))
        exe_frame.grid_columnconfigure(0, weight=1)

        target_frame = ctk.CTkFrame(root)
        target_frame.pack(fill="x", pady=6)
        ctk.CTkLabel(target_frame, text="UI Automation target", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, columnspan=4, sticky="w", padx=10, pady=(10, 4))
        self.control_type_var = tk.StringVar(value="ComboBox")
        self.automation_id_var = tk.StringVar()
        self.title_re_var = tk.StringVar(value=".*")
        ctk.CTkLabel(target_frame, text="Control type").grid(row=1, column=0, sticky="w", padx=10)
        ctk.CTkEntry(target_frame, textvariable=self.control_type_var, width=130).grid(row=2, column=0, padx=10, pady=(0, 10), sticky="w")
        ctk.CTkLabel(target_frame, text="Automation ID (optional)").grid(row=1, column=1, sticky="w", padx=10)
        ctk.CTkEntry(target_frame, textvariable=self.automation_id_var).grid(row=2, column=1, padx=10, pady=(0, 10), sticky="ew")
        ctk.CTkLabel(target_frame, text="Title regex").grid(row=1, column=2, sticky="w", padx=10)
        ctk.CTkEntry(target_frame, textvariable=self.title_re_var).grid(row=2, column=2, padx=10, pady=(0, 10), sticky="ew")
        ctk.CTkButton(target_frame, text="Inspect", command=self._inspect).grid(row=2, column=3, padx=(0, 10), pady=(0, 10))

        self.fallback_x_var = tk.StringVar(value="0.50")
        self.fallback_y_var = tk.StringVar(value="0.19")
        ctk.CTkLabel(target_frame, text="Fallback X (relative)").grid(row=3, column=0, sticky="w", padx=10)
        ctk.CTkEntry(target_frame, textvariable=self.fallback_x_var, width=130).grid(row=4, column=0, padx=10, pady=(0, 10), sticky="w")
        ctk.CTkLabel(target_frame, text="Fallback Y (relative)").grid(row=3, column=1, sticky="w", padx=10)
        ctk.CTkEntry(target_frame, textvariable=self.fallback_y_var).grid(row=4, column=1, padx=10, pady=(0, 10), sticky="ew")
        ctk.CTkButton(target_frame, text="Capture target (3s)", command=self._capture_target).grid(row=4, column=2, columnspan=2, padx=(10, 10), pady=(0, 10), sticky="ew")
        target_frame.grid_columnconfigure(1, weight=1)
        target_frame.grid_columnconfigure(2, weight=1)

        status_frame = ctk.CTkFrame(root)
        status_frame.pack(fill="x", pady=6)
        ctk.CTkLabel(status_frame, text="Set status (2 lines)", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, columnspan=3, sticky="w", padx=10, pady=(10, 4))
        self.status_line_vars = [tk.StringVar() for _ in range(2)]
        self.status_entries = []
        for idx, var in enumerate(self.status_line_vars, start=1):
            ctk.CTkLabel(status_frame, text=f"Line {idx}", width=55).grid(row=idx, column=0, sticky="w", padx=(10, 4), pady=(2, 4))
            entry = ctk.CTkEntry(status_frame, textvariable=var, placeholder_text=f"text{idx}")
            entry.grid(row=idx, column=1, sticky="ew", padx=(0, 8), pady=(2, 4))
            self.status_entries.append(entry)
        ctk.CTkButton(status_frame, text="Apply 2 lines", command=self._apply_clicked).grid(row=1, column=2, rowspan=2, padx=(0, 10), pady=(2, 4), sticky="ns")
        self.status_preview = ctk.CTkTextbox(status_frame, height=92)
        self.status_preview.grid(row=3, column=0, columnspan=3, sticky="ew", padx=10, pady=(6, 10))
        self.status_preview.configure(state="disabled")

        style_row = ctk.CTkFrame(status_frame, fg_color="transparent")
        style_row.grid(row=4, column=0, columnspan=3, sticky="ew", padx=10, pady=(0, 8))
        self.random_color_var = tk.BooleanVar(value=False)
        self.marquee_var = tk.BooleanVar(value=False)
        self.language_var = tk.StringVar(value="EN")
        self.random_color_check = ctk.CTkCheckBox(style_row, text="Random Color", variable=self.random_color_var, command=self._style_changed)
        self.random_color_check.pack(side="left", padx=(0, 14))
        self.marquee_check = ctk.CTkCheckBox(style_row, text="Marquee", variable=self.marquee_var, command=self._style_changed)
        self.marquee_check.pack(side="left", padx=(0, 14))
        ctk.CTkLabel(style_row, text="Language").pack(side="left", padx=(10, 6))
        self.language_menu = ctk.CTkOptionMenu(style_row, values=["EN", "TH"], variable=self.language_var, width=80, command=self._language_changed)
        self.language_menu.pack(side="left")

        for var in self.status_line_vars:
            var.trace_add("write", self._status_lines_changed)
        status_frame.grid_columnconfigure(1, weight=1)

        preset_frame = ctk.CTkFrame(root)
        preset_frame.pack(fill="x", pady=6)
        preset_header = ctk.CTkFrame(preset_frame, fg_color="transparent")
        preset_header.pack(fill="x", padx=10, pady=(10, 4))
        ctk.CTkLabel(preset_header, text="Presets (one per line)", font=ctk.CTkFont(weight="bold")).pack(side="left")
        ctk.CTkButton(preset_header, text="Read Camfrog History", width=155, command=self._read_registry_clicked).pack(side="right")
        self.registry_auto_var = tk.BooleanVar(value=True)
        ctk.CTkCheckBox(preset_frame, text="Read Camfrog status history on startup (read-only)", variable=self.registry_auto_var).pack(anchor="w", padx=10, pady=(0, 6))
        self.presets_box = ctk.CTkTextbox(preset_frame, height=100)
        self.presets_box.pack(fill="x", padx=10, pady=(0, 8))

        history_header = ctk.CTkFrame(preset_frame, fg_color="transparent")
        history_header.pack(fill="x", padx=10, pady=(0, 4))
        ctk.CTkLabel(history_header, text="Camfrog History (read-only)", font=ctk.CTkFont(weight="bold")).pack(side="left")
        ctk.CTkButton(history_header, text="Import all → Presets", width=145, command=self._import_history_all).pack(side="right")
        self.history_box = ctk.CTkTextbox(preset_frame, height=105)
        self.history_box.pack(fill="x", padx=10, pady=(0, 10))
        self.history_box.configure(state="disabled")
        self._history_values = []

        auto_frame = ctk.CTkFrame(root)
        auto_frame.pack(fill="x", pady=6)
        self.rotation_var = tk.BooleanVar()
        self.start_windows_var = tk.BooleanVar()
        self.autostart_camfrog_var = tk.BooleanVar()
        self.restore_state_var = tk.BooleanVar(value=True)
        self.background_only_var = tk.BooleanVar(value=True)
        self.foreground_fallback_var = tk.BooleanVar(value=False)
        self.mode_var = tk.StringVar(value="sequential")
        self.interval_var = tk.StringVar(value="10")
        self.interval_unit_var = tk.StringVar(value="minutes")
        ctk.CTkCheckBox(auto_frame, text="Enable status rotation", variable=self.rotation_var).grid(row=0, column=0, sticky="w", padx=10, pady=10)
        ctk.CTkLabel(auto_frame, text="Interval").grid(row=0, column=1, sticky="e")
        ctk.CTkEntry(auto_frame, textvariable=self.interval_var, width=70).grid(row=0, column=2, padx=(10, 4))
        self.interval_unit_menu = ctk.CTkOptionMenu(auto_frame, values=["seconds", "minutes", "hours"], variable=self.interval_unit_var, width=105, command=self._interval_unit_changed)
        self.interval_unit_menu.grid(row=0, column=3, padx=(0, 8))
        ctk.CTkOptionMenu(auto_frame, values=["sequential", "random"], variable=self.mode_var, width=120).grid(row=0, column=4, padx=(0, 10))
        ctk.CTkCheckBox(auto_frame, text="Start with Windows", variable=self.start_windows_var).grid(row=1, column=0, sticky="w", padx=10, pady=(0, 10))
        ctk.CTkCheckBox(auto_frame, text="Start Camfrog if not running", variable=self.autostart_camfrog_var).grid(row=1, column=1, columnspan=2, sticky="w", pady=(0, 10))
        self.background_only_check = ctk.CTkCheckBox(auto_frame, text="Background only (do not focus/restore Camfrog)", variable=self.background_only_var, command=self._background_only_toggled)
        self.background_only_check.grid(row=2, column=0, columnspan=3, sticky="w", padx=10, pady=(0, 6))
        self.foreground_fallback_check = ctk.CTkCheckBox(auto_frame, text="Allow foreground fallback if background fails", variable=self.foreground_fallback_var, command=self._foreground_fallback_toggled)
        self.foreground_fallback_check.grid(row=3, column=0, columnspan=3, sticky="w", padx=10, pady=(0, 10))

        buttons = ctk.CTkFrame(root, fg_color="transparent")
        buttons.pack(fill="x", pady=12)
        ctk.CTkButton(buttons, text="Save settings", command=self._save).pack(side="left", padx=(0, 8))
        ctk.CTkButton(buttons, text="Start rotation", command=self._start_rotation).pack(side="left", padx=8)
        ctk.CTkButton(buttons, text="Stop rotation", command=self._stop_rotation).pack(side="left", padx=8)
        ctk.CTkButton(buttons, text="Open config folder", command=self._open_config_dir).pack(side="right")

    def _background_only_toggled(self):
        # User explicitly enabled Background-only: disable foreground fallback.
        if bool(self.background_only_var.get()):
            self.foreground_fallback_var.set(False)

    def _foreground_fallback_toggled(self):
        # User explicitly enabled foreground fallback: background-only must yield.
        if bool(self.foreground_fallback_var.get()):
            self.background_only_var.set(False)

    def _style_changed(self):
        self._refresh_status_preview()
        try:
            self._sync_ui_to_config()
        except Exception:
            pass

    def _language_changed(self, value=None):
        lang = str(value or self.language_var.get()).upper()
        self.language_var.set("TH" if lang == "TH" else "EN")
        # Keep translation deliberately limited to controls added in this release;
        # existing labels remain stable to avoid breaking automation/tests.
        if hasattr(self, "random_color_check"):
            self.random_color_check.configure(text="สุ่มสีข้อความ" if self.language_var.get() == "TH" else "Random Color")
            self.marquee_check.configure(text="ข้อความวิ่ง" if self.language_var.get() == "TH" else "Marquee")
        try:
            self._sync_ui_to_config()
        except Exception:
            pass

    def _styled_value(self, value: str, advance: bool = False) -> str:
        styles = self.config_data.get("status", {}).get("styles", {})
        styled, next_offset, _ = apply_styles(
            value,
            random_color_enabled=bool(self.random_color_var.get()) if hasattr(self, "random_color_var") else bool(styles.get("random_color", False)),
            marquee_enabled=bool(self.marquee_var.get()) if hasattr(self, "marquee_var") else bool(styles.get("marquee", False)),
            marquee_offset=self._marquee_offset,
            marquee_width=int(styles.get("marquee_width", 28)),
            color_template=str(styles.get("color_template", "[color={color}]{text}[/color]")),
            palette=styles.get("palette", []),
        )
        if advance and (bool(self.marquee_var.get()) if hasattr(self, "marquee_var") else bool(styles.get("marquee", False))):
            self._marquee_offset = next_offset
        return styled

    def _status_lines_changed(self, *_):
        self._refresh_status_preview()

    def _compose_status(self) -> str:
        # Compose text1/text2 into the two-line status payload.
        return compose_two_lines([var.get() for var in self.status_line_vars])

    def _refresh_status_preview(self):
        if not hasattr(self, "status_preview"):
            return
        value = self._styled_value(self._compose_status(), advance=False) if hasattr(self, "status_line_vars") else ""
        self.status_preview.configure(state="normal")
        self.status_preview.delete("1.0", "end")
        self.status_preview.insert("1.0", value)
        self.status_preview.configure(state="disabled")

    def _load_config_to_ui(self):
        c = self.config_data
        self.exe_var.set(c["camfrog"].get("executable", ""))
        self.control_type_var.set(c["target"].get("control_type", "ComboBox"))
        self.automation_id_var.set(c["target"].get("automation_id", ""))
        self.title_re_var.set(c["target"].get("title_regex", ".*"))
        self.fallback_x_var.set(str(c["target"].get("fallback_relative_x", 0.50)))
        self.fallback_y_var.set(str(c["target"].get("fallback_relative_y", 0.19)))
        self.rotation_var.set(bool(c["status"]["rotation"].get("enabled", False)))
        interval_seconds = int(c["status"]["rotation"].get("interval_seconds", 600))
        interval_amount, interval_unit = seconds_to_interval(interval_seconds)
        self.interval_var.set(str(interval_amount))
        self.interval_unit_var.set(interval_unit)
        self.mode_var.set(c["status"]["rotation"].get("mode", "sequential"))
        self.start_windows_var.set(bool(c["startup"].get("windows_startup", False)))
        self.autostart_camfrog_var.set(bool(c["camfrog"].get("auto_start", False)))
        self.restore_state_var.set(bool(c["camfrog"].get("restore_window_state", True)))
        self.background_only_var.set(bool(c.get("advanced", {}).get("background_only", True)))
        self.foreground_fallback_var.set(bool(c.get("advanced", {}).get("fallback_enabled", False)) and not bool(self.background_only_var.get()))
        self.registry_auto_var.set(bool(c.get("registry", {}).get("import_presets_on_start", True)))
        styles = c.get("status", {}).get("styles", {})
        self.random_color_var.set(bool(styles.get("random_color", False)))
        self.marquee_var.set(bool(styles.get("marquee", False)))
        self.language_var.set(str(c.get("ui", {}).get("language", "EN")).upper())
        self._language_changed(self.language_var.get())
        self.presets_box.delete("1.0", "end")
        self.presets_box.insert("1.0", "\n".join(c["status"].get("presets", [])))
        editor_lines = c["status"].get("editor_lines", [])
        if not editor_lines:
            editor_lines = c["status"].get("presets", [])[:2]
        editor_lines = list(editor_lines)[:2] + [""] * max(0, 2 - len(editor_lines))
        for var, value in zip(self.status_line_vars, editor_lines[:2]):
            var.set(str(value))
        self._refresh_status_preview()

    def _sync_ui_to_config(self):
        c = self.config_data
        c["camfrog"]["executable"] = self.exe_var.get().strip()
        c["camfrog"]["auto_start"] = bool(self.autostart_camfrog_var.get())
        c["camfrog"]["restore_window_state"] = bool(self.restore_state_var.get())
        c.setdefault("advanced", {})["background_only"] = bool(self.background_only_var.get())
        c["advanced"]["fallback_enabled"] = bool(self.foreground_fallback_var.get()) and not bool(self.background_only_var.get())
        c.setdefault("target", {})["background_enabled"] = True
        c["target"]["control_type"] = self.control_type_var.get().strip() or "ComboBox"
        c["target"]["automation_id"] = self.automation_id_var.get().strip()
        c["target"]["title_regex"] = self.title_re_var.get().strip() or ".*"
        try:
            fx = float(self.fallback_x_var.get().strip())
            fy = float(self.fallback_y_var.get().strip())
        except ValueError:
            fx, fy = 0.50, 0.19
        c["target"]["fallback_relative_x"] = min(1.0, max(0.0, fx))
        c["target"]["fallback_relative_y"] = min(1.0, max(0.0, fy))
        presets = [x.strip() for x in self.presets_box.get("1.0", "end").splitlines() if x.strip()]
        c["status"]["presets"] = presets
        c["status"]["editor_lines"] = [var.get().replace("\x00", "") for var in self.status_line_vars]
        c["status"]["rotation"]["enabled"] = bool(self.rotation_var.get())
        unit = self.interval_unit_var.get()
        try:
            interval = interval_to_seconds(
                self.interval_var.get(),
                unit,
                minimum_seconds=int(c.get("advanced", {}).get("minimum_interval_seconds", 5)),
            )
        except ValueError:
            # Keep the prior known-good value instead of silently changing units.
            interval = int(c["status"]["rotation"].get("interval_seconds", 600))
        c["status"]["rotation"]["interval_seconds"] = interval
        c["status"]["rotation"]["mode"] = self.mode_var.get()
        c["startup"]["windows_startup"] = bool(self.start_windows_var.get())
        c.setdefault("registry", {})["import_presets_on_start"] = bool(self.registry_auto_var.get())
        styles = c["status"].setdefault("styles", {})
        styles["random_color"] = bool(self.random_color_var.get())
        styles["marquee"] = bool(self.marquee_var.get())
        c.setdefault("ui", {})["language"] = "TH" if self.language_var.get().upper() == "TH" else "EN"
        self.controller.config = c
        return c


    def _show_native_profile(self):
        self._sync_ui_to_config()
        info = self.controller.native_profile_info()
        if info.get("matched"):
            anchors = info.get("anchors", {})
            summary = "\n".join(f"{k}: 0x{int(v):X}" for k, v in list(anchors.items())[:5])
            messagebox.showinfo(
                "Camfrog Native Profile",
                f"Known profile matched.\n\n{info.get('name')}\nSHA-256: {info.get('sha256')}\n\n"
                f"Known classes: {', '.join(info.get('classes', []))}\n\n"
                f"Diagnostic RVAs (not invoked):\n{summary}"
            )
            self.state_label.configure(text="Known Camfrog native profile matched")
        elif info.get("sha256"):
            messagebox.showwarning(
                "Camfrog Native Profile",
                f"Unknown Camfrog binary. Generic UI/Win32 integration will be used.\n\nSHA-256: {info.get('sha256')}"
            )
            self.state_label.configure(text="Unknown Camfrog binary; generic integration mode")
        else:
            messagebox.showwarning("Camfrog Native Profile", "Select or detect Camfrog Video Chat.exe first.")

    def _auto_import_registry_presets(self):
        if not self.registry_auto_var.get():
            return
        self._read_registry_presets(silent=True)

    def _read_registry_clicked(self):
        self._read_registry_presets(silent=False)

    def _read_registry_presets(self, silent: bool = False):
        if os.name != "nt":
            if not silent:
                messagebox.showwarning("Camfrog Registry", "Registry import is available on Windows only.")
            return
        self.state_label.configure(text="Reading Camfrog custom statuses from Registry...")
        threading.Thread(target=self._registry_worker, args=(silent,), daemon=True).start()

    def _registry_worker(self, silent: bool):
        try:
            result = read_camfrog_custom_statuses()
            self.after(0, lambda: self._registry_import_done(result, silent))
        except Exception as exc:
            log.exception("Registry status import failed")
            self.after(0, lambda exc=exc: self._registry_import_failed(exc, silent))

    def _registry_import_done(self, result, silent: bool):
        # History is displayed first and is not silently merged into Presets.
        # This makes it obvious what Camfrog actually exposed and prevents bad
        # registry candidates from contaminating user presets.
        self._history_values = list(result.statuses)
        self.history_box.configure(state="normal")
        self.history_box.delete("1.0", "end")
        self.history_box.insert("1.0", "\n".join(self._history_values))
        self.history_box.configure(state="disabled")
        if result.statuses:
            self.state_label.configure(text=f"History: {len(result.statuses)} status value(s) found from {result.candidate_values} candidate value(s)")
            if not silent:
                sample_sources = "\n".join(dict.fromkeys(result.sources[:8]))
                messagebox.showinfo("Camfrog History", f"Found {len(result.statuses)} status history value(s).\nNothing was imported automatically.\nUse 'Import all → Presets' if the list is correct.\n\nSources:\n{sample_sources}")
        else:
            self.state_label.configure(text=f"History: none found (scanned {result.scanned_keys} keys, {result.candidate_values} candidates)")
            if not silent:
                messagebox.showinfo("Camfrog History", f"No custom-status history was decoded.\n\nScanned {result.scanned_keys} Camfrog registry keys and {result.candidate_values} explicit status/custom candidate values.\n\nThis build may serialize history in a different binary layout or outside Registry.")

    def _import_history_all(self):
        values = list(getattr(self, "_history_values", []))
        if not values:
            messagebox.showinfo("Camfrog History", "Read Camfrog History first; no decoded history is currently available.")
            return
        current = [x.strip() for x in self.presets_box.get("1.0", "end").splitlines() if x.strip()]
        merged = merge_presets(current, values)
        added = len(merged) - len(merge_presets(current, []))
        self.presets_box.delete("1.0", "end")
        self.presets_box.insert("1.0", "\n".join(merged))
        self.config_data["status"]["presets"] = merged
        self.store.save(self.config_data)
        self.state_label.configure(text=f"Imported {added} history item(s) into Presets")

    def _registry_import_failed(self, exc: Exception, silent: bool):
        self.state_label.configure(text=f"Registry read error: {exc}")
        if not silent:
            messagebox.showerror("Camfrog Registry", str(exc))

    def _auto_detect_if_needed(self):
        if not self.exe_var.get().strip():
            self._detect(silent=True)

    def _browse(self):
        path = filedialog.askopenfilename(filetypes=[("Executable", "*.exe"), ("All files", "*.*")])
        if path:
            self.exe_var.set(path)

    def _detect(self, silent=False):
        path = discover_executable()
        if path:
            self.exe_var.set(path)
            self.state_label.configure(text=f"Detected: {path}")
        elif not silent:
            messagebox.showwarning("Camfrog", "Camfrog executable/process was not detected. Use Browse to select Camfrog.exe.")

    def _save(self):
        c = self._sync_ui_to_config()
        self.store.save(c)
        try:
            set_start_with_windows(c["startup"]["windows_startup"])
        except Exception as exc:
            messagebox.showwarning("Startup", f"Settings saved, but Windows startup could not be updated:\n{exc}")
            return
        self.state_label.configure(text="Settings saved")

    def _apply_clicked(self):
        self._sync_ui_to_config()
        value = self._compose_status()
        if not value.strip():
            messagebox.showwarning("Status", "Enter text in Line 1-2 first.")
            return
        value = self._styled_value(value, advance=True)
        self.state_label.configure(text="Changing status...")
        threading.Thread(target=self._apply_worker, args=(value,), daemon=True).start()

    def _apply_worker(self, value):
        result = self.controller.set_status(value)
        self.after(0, lambda: self._show_result(result))

    def _apply_status_background(self, value):
        value = self._styled_value(value, advance=True)
        result = self.controller.set_status(value)
        self.after(0, lambda: self.state_label.configure(text=result.message if result.ok else f"ERROR: {result.message}"))

    def _show_result(self, result):
        self.state_label.configure(text=result.message if result.ok else f"ERROR: {result.message}")
        if not result.ok:
            messagebox.showerror("Camfrog Status", result.message)

    def _start_rotation(self):
        c = self._sync_ui_to_config()
        presets = c["status"]["presets"]
        if not presets:
            messagebox.showwarning("Rotation", "Add at least one preset.")
            return
        interval = c["status"]["rotation"]["interval_seconds"]
        self.rotation.start(presets, interval, c["status"]["rotation"]["mode"])
        self.rotation_var.set(True)
        c["status"]["rotation"]["enabled"] = True
        self.store.save(c)
        self.state_label.configure(text=f"Rotation started: 1 preset per {self._format_interval(interval)}; first change after full interval")


    @staticmethod
    def _format_interval(seconds: int) -> str:
        return format_interval(seconds)

    def _interval_unit_changed(self, unit: str):
        # Make unit selection visibly active and immediately persist a valid conversion.
        try:
            c = self._sync_ui_to_config()
            seconds = int(c["status"]["rotation"]["interval_seconds"])
            self.state_label.configure(text=f"Interval set to {self._format_interval(seconds)}")
        except Exception as exc:
            self.state_label.configure(text=f"Interval error: {exc}")

    def _stop_rotation(self):
        self.rotation.stop()
        self.rotation_var.set(False)
        self.config_data["status"]["rotation"]["enabled"] = False
        self.store.save(self.config_data)
        self.state_label.configure(text="Rotation stopped")


    def _capture_target(self):
        self._sync_ui_to_config()
        self._capture_countdown = 3
        self._capture_tick()

    def _capture_tick(self):
        if self._capture_countdown > 0:
            self.state_label.configure(
                text=f"Move mouse over Camfrog status field — capturing in {self._capture_countdown}s..."
            )
            self._capture_countdown -= 1
            self.after(1000, self._capture_tick)
            return

        self.state_label.configure(text="Capturing target...")
        threading.Thread(target=self._capture_target_worker, daemon=True).start()

    def _capture_target_worker(self):
        try:
            if os.name != "nt":
                raise RuntimeError("Target capture is available on Windows only")
            import win32api

            # pywinauto enumeration can be slow for custom-rendered applications;
            # keep it off the Tk UI thread so Windows never marks the app hung.
            win = self.controller.find_window()
            rect = win.rectangle()
            x, y = win32api.GetCursorPos()
            if not (rect.left <= x <= rect.right and rect.top <= y <= rect.bottom):
                raise RuntimeError("Mouse cursor is not over the Camfrog window")
            rx = (x - rect.left) / max(1, rect.width())
            ry = (y - rect.top) / max(1, rect.height())
            self.after(0, lambda: self._capture_target_success(rx, ry))
        except Exception as exc:
            self.after(0, lambda exc=exc: self._capture_target_failed(exc))

    def _capture_target_success(self, rx: float, ry: float):
        self.fallback_x_var.set(f"{rx:.4f}")
        self.fallback_y_var.set(f"{ry:.4f}")
        self._sync_ui_to_config()
        self.store.save(self.config_data)
        self.state_label.configure(text=f"Captured fallback target X={rx:.4f}, Y={ry:.4f}")
        messagebox.showinfo("Target captured", "Fallback target saved. You can now test with Apply now.")

    def _capture_target_failed(self, exc: Exception):
        self.state_label.configure(text=f"ERROR: {exc}")
        messagebox.showerror("Capture failed", str(exc))

    def _inspect(self):
        self._sync_ui_to_config()
        self.state_label.configure(text="Inspecting Camfrog controls...")
        threading.Thread(target=self._inspect_worker, daemon=True).start()

    def _inspect_worker(self):
        try:
            result = self.controller.ensure_running()
            if not result.ok:
                raise RuntimeError(result.message)
            controls = self.controller.inspect_controls()
            interesting = [x for x in controls if x["control_type"] in {"ComboBox", "Edit", "Text"} and (x["title"] or x["automation_id"])]
            payload = json.dumps(interesting[:100], indent=2, ensure_ascii=False)
            path = self.store.dir / "uia-controls.json"
            path.write_text(payload, encoding="utf-8")
            self.after(0, lambda: messagebox.showinfo("Inspect complete", f"Saved {len(interesting)} candidate controls to:\n{path}"))
            self.after(0, lambda: self.state_label.configure(text="Inspect complete"))
        except Exception as exc:
            self.after(0, lambda: messagebox.showerror("Inspect failed", str(exc)))
            self.after(0, lambda: self.state_label.configure(text=f"ERROR: {exc}"))

    def _open_config_dir(self):
        self.store.dir.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(self.store.dir)  # type: ignore[attr-defined]
        else:
            messagebox.showinfo("Config folder", str(self.store.dir))

    def _resume_background_automation(self):
        c = self.config_data
        if c.get("status", {}).get("rotation", {}).get("enabled", False):
            presets = c.get("status", {}).get("presets", [])
            if presets:
                interval = max(int(c.get("advanced", {}).get("minimum_interval_seconds", 5)), int(c["status"]["rotation"].get("interval_seconds", 600)))
                mode = c["status"]["rotation"].get("mode", "sequential")
                self.rotation.start(presets, interval, mode)
                self.state_label.configure(text=f"Background rotation: 1 preset per {self._format_interval(interval)}")
        if c.get("startup", {}).get("start_minimized", False):
            self.withdraw()

    def _start_tray(self):
        if os.name != "nt" or self._tray_icon is not None:
            return
        try:
            import pystray
            from PIL import Image, ImageDraw

            image = Image.new("RGB", (64, 64), "black")
            draw = ImageDraw.Draw(image)
            draw.ellipse((8, 8, 56, 56), outline="white", width=5)
            draw.text((23, 18), "C", fill="white")

            menu = pystray.Menu(
                pystray.MenuItem("Open", lambda icon, item: self.after(0, self._show_from_tray)),
                pystray.MenuItem("Pause rotation", lambda icon, item: self.after(0, self._stop_rotation)),
                pystray.MenuItem("Exit", lambda icon, item: self.after(0, self._exit_app)),
            )
            self._tray_icon = pystray.Icon("CamfrogStatusChanger", image, "Camfrog Status Changer", menu)
            self._tray_thread = threading.Thread(target=self._tray_icon.run, daemon=True)
            self._tray_thread.start()
        except Exception:
            log.exception("Could not start system tray")

    def _show_from_tray(self):
        self.deiconify()
        self.lift()

    def _exit_app(self):
        self._exiting = True
        self.rotation.stop()
        if self._tray_icon is not None:
            try:
                self._tray_icon.stop()
            except Exception:
                pass
        self.destroy()

    def _on_close(self):
        # Closing the control panel keeps automation running in the tray.
        if self._exiting:
            self._exit_app()
            return
        self.withdraw()
