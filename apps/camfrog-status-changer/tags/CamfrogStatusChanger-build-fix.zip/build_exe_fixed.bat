@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

title Camfrog Status Changer - Safe Build

set "APP=CamfrogStatusChanger"
set "OLD_DIST=%CD%\dist"
set "NEW_DIST=%CD%\dist-new"
set "WORK=%CD%\build"
set "SPEC=%CD%\%APP%.spec"

echo ==================================================
echo Camfrog Status Changer - Safe Windows Build
echo ==================================================
echo.

where py >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python launcher "py" not found.
  pause
  exit /b 1
)

echo [1/7] Closing running %APP%.exe instances...
taskkill /F /IM "%APP%.exe" >nul 2>&1

rem Wait up to 10 seconds for Windows to release the executable handle.
for /L %%I in (1,1,20) do (
  tasklist /FI "IMAGENAME eq %APP%.exe" 2>NUL | find /I "%APP%.exe" >NUL
  if errorlevel 1 goto :released
  >nul timeout /t 1 /nobreak
)

:released
echo [2/7] Checking output lock...
if exist "%OLD_DIST%\%APP%.exe" (
  del /F /Q "%OLD_DIST%\%APP%.exe" >nul 2>&1
  if exist "%OLD_DIST%\%APP%.exe" (
    echo [ERROR] Existing EXE is still locked:
    echo         "%OLD_DIST%\%APP%.exe"
    echo.
    echo Close Explorer preview, antivirus scan, debugger, or any running copy and retry.
    pause
    exit /b 5
  )
)

echo [3/7] Installing/updating build dependencies...
py -m pip install -r requirements.txt
if errorlevel 1 goto :failed
py -m pip install --upgrade pyinstaller
if errorlevel 1 goto :failed

echo [4/7] Cleaning staging directories...
if exist "%NEW_DIST%" rmdir /S /Q "%NEW_DIST%"
if exist "%WORK%" rmdir /S /Q "%WORK%"
if exist "%SPEC%" del /F /Q "%SPEC%"
mkdir "%NEW_DIST%" >nul 2>&1

echo [5/7] Building into isolated staging output...
set "ICON_ARG="
if exist "%CD%\app.ico" set "ICON_ARG=--icon=%CD%\app.ico"

py -m PyInstaller ^
  --clean ^
  --noconfirm ^
  --onefile ^
  --windowed ^
  --name "%APP%" ^
  --distpath "%NEW_DIST%" ^
  --workpath "%WORK%" ^
  %ICON_ARG% ^
  app.py
if errorlevel 1 goto :failed

if not exist "%NEW_DIST%\%APP%.exe" (
  echo [ERROR] Build finished without expected executable.
  goto :failed
)

echo [6/7] Publishing validated executable...
if not exist "%OLD_DIST%" mkdir "%OLD_DIST%"
copy /Y "%NEW_DIST%\%APP%.exe" "%OLD_DIST%\%APP%.exe" >nul
if errorlevel 1 (
  echo [ERROR] Could not publish the new executable to dist.
  goto :failed
)

for %%F in ("%OLD_DIST%\%APP%.exe") do set "SIZE=%%~zF"
if "%SIZE%"=="0" (
  echo [ERROR] Published executable has zero size.
  goto :failed
)

echo [7/7] Cleaning staging output...
rmdir /S /Q "%NEW_DIST%" >nul 2>&1

echo.
echo ==================================================
echo BUILD SUCCESS
echo ==================================================
echo Output:
echo "%OLD_DIST%\%APP%.exe"
echo Size: %SIZE% bytes
echo.
pause
exit /b 0

:failed
echo.
echo ==================================================
echo BUILD FAILED
echo ==================================================
echo See the errors above. Existing dist EXE was not replaced unless publish completed.
echo.
pause
exit /b 1
